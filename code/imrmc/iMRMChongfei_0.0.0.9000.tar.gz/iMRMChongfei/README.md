# IMRMC-Devin

This is the R package, which is converted from the iMRMC Java codes.
