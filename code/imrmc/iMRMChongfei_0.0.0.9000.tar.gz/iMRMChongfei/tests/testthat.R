library(testthat)
library(MRMC)

test_check("MRMC")
