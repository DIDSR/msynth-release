library(iMRMC)
#library(iMRMChongfei)
library(testthat)
library(magrittr)
library(dplyr)

context("doIMRMC_R given file name")

# Create data #####

# initialize the random number generator
iMRMC::init.lecuyerRNG()

# Create a sample configuration file
config <- iMRMC::sim.gRoeMetz.config()

# Simulate an MRMC ROC data set
dFrame.imrmc <- iMRMC::sim.gRoeMetz(config)

# Round the scores to four digits (it's what the java program does)
dFrame.imrmc$score <- round(dFrame.imrmc$score, digits = 4)

# Write data to file
fileName <- file.path("tests", "testthat", "input.imrmc")
write("This is row 1 of front matter", file = fileName)
write("This is row 2 of front matter", file = fileName, append = TRUE)
write("BEGIN DATA:", file = fileName, append = TRUE)
write.table(dFrame.imrmc, file = fileName, sep = ",",
            append = TRUE, quote = FALSE, row.names = FALSE, col.names = FALSE)



# Analyze data #####
# Analyze the MRMC ROC data with java code
system.time({
  result_java <- iMRMC::doIMRMC(dFrame.imrmc)
})

## Analyze the MRMC ROC data using new R code
system.time({
  result_R <- doIMRMC_R(dFrame.imrmc)
})



#### test Ustat output ###############
# [1] "inputFile"        "date"             "iMRMCversion"

# [4] "NR"               "N0"               "N1"
# [7] "modalityA"        "modalityB"        "UstatOrMLE"       "AUCA"             "varAUCA"          "AUCB"
# [13] "varAUCB"          "AUCAminusAUCB"    "varAUCAminusAUCB" "pValueNormal"     "botCInormal"      "topCInormal"
# [19] "rejectNormal"     "dfBDG"            "pValueBDG"        "botCIBDG"         "topCIBDG"         "rejectBDG"

# [25] "dfHillis"         "pValueHillis"     "botCIHillis"      "topCIHillis"      "rejectHillis"

# Notice the columns that we compare
target <- result_java$Ustat[,4:24]
current <- result_R$Ustat

test_that(
  "doIMRMC Ustat output does not change", {
    expect_equal(target, current)
  }
)



#### test MLEstat output ###############
# [1] "inputFile"        "date"             "iMRMCversion"

# [4] "NR"               "N0"               "N1"
# [7] "modalityA"        "modalityB"        "UstatOrMLE"       "AUCA"             "varAUCA"          "AUCB"
# [13] "varAUCB"          "AUCAminusAUCB"    "varAUCAminusAUCB" "pValueNormal"     "botCInormal"      "topCInormal"
# [19] "rejectNormal"     "dfBDG"            "pValueBDG"        "botCIBDG"         "topCIBDG"         "rejectBDG"

# [25] "dfHillis"         "pValueHillis"     "botCIHillis"      "topCIHillis"      "rejectHillis"

# Notice the columns that we compare
target <- result_java$MLEstat[,4:24]
current <- result_R$MLEstat

test_that(
  "doIMRMC MLEstat output does not change", {
    expect_equal(target, current)
  }
)



## test varDecomp$BDG  ##############################################
target <- result_java$varDecomp$BDG
current <- result_R$varDecomp$BDG

test_that(
  "doIMRMC varcomp-BDG output does not change", {
    expect_equal(target, current,tolerance = 1e-6)
  }
)




## test varDecomp$BCK  ########
target <- result_java$varDecomp$BCK
current <- result_R$varDecomp$BCK

test_that(
  "doIMRMC varcomp-BCK output does not change", {
    expect_equal(target, current,tolerance = 1e-6)
  }
)

#### test perReader output ###############
# [1] "inputFile"        "date"             "iMRMCversion"

# [4] "readerID"         "N0"               "N1"
# [7] "modalityA"        "modalityB"        "AUCA"             "varAUCA"          "AUCB"             "varAUCB"
# [13] "AUCAminusAUCB"    "varAUCAminusAUCB"

# [15] "pValueNormal"     "botCInormal"      "topCInormal"      "rejectNormal"
# [19] "dfBDG"            "pValueBDG"        "botCIBDG"         "topCIBDG"         "rejectBDG"        "dfHillis"
# [25] "pValueHillis"     "botCIHillis"      "topCIHillis"      "rejectHillis"

# Notice the columns that we compare
# Future work should produce the results for columns 15-23
# Future work should produce the reader by modality covariance matrix
target <- result_java$perReader[,4:14]
current <- result_R$perReader

# Do the comparison
test_that(
  "doIMRMC perReader output does not change", {
    expect_equal(target, current)
  }
)



#### test ROC output ###############
# target <- capture.output(str(result_java$ROC))
# current <- capture.output(str(result_R$ROC))
target <- result_java$ROC
current <- result_R$ROC

# target has attributes
# As these are not data, we strip them out of the test
# attr(result_java$ROC, "dim") <- NULL
# attr(result_java$ROC, "call") <- NULL
# attr(result_java$ROC, "class") <- NULL

# names(current) <- NULL

# This shows there three differences that are worse than the rest
test_that(
  "doIMRMC ROC output does not change", {
    expect_equal(target, current, tolerance = 1e-4)
  }
)
