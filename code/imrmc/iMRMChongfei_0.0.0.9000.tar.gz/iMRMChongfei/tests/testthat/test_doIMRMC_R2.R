# In this test we compare doIMRMC that uses the java engine to
# to doIMRMC_R that uses R code
# Furthermore, this is a test of a dataset that has two modalities


library(iMRMC)
library(iMRMChongfei)
library(testthat)

testthat::context("doIMRMC_R")

# Simulate data ###############################################################

# initialize the random number generator
iMRMC::init.lecuyerRNG(stream = 2)

# Create a sample configuration file
config <- iMRMC::sim.gRoeMetz.config()

# Simulate an MRMC ROC data set
dFrame.imrmc <- iMRMC::sim.gRoeMetz(config)
dFrame.imrmc$modalityID <- as.character(dFrame.imrmc$modalityID)
dFrame.imrmc$readerID <- as.character(dFrame.imrmc$readerID)
dFrame.imrmc$caseID <- as.character(dFrame.imrmc$caseID)

# Delete some data to create "arbitrary" study design
del = sample(100:880,100)
dFrame.imrmc <- dFrame.imrmc[-del, ]

# Delete the first reader from modality A
dFrame.imrmc <- dFrame.imrmc[!(
  dFrame.imrmc$modalityID == "testA" &
    dFrame.imrmc$readerID == "reader1"), ]

# Delete the first case from modality B
dFrame.imrmc <- dFrame.imrmc[!(
  dFrame.imrmc$modalityID == "testB" &
    dFrame.imrmc$caseID == "negCase1"), ]

# Rename some negative cases and resort
# This puts the truth and reader data of the renamed cases
# at the bottom of the data frame
for (i in 1:nrow(dFrame.imrmc)) {
  dFrame.imrmc[i, "caseID"] <-
    sub("negCase1", "x-negCase1", dFrame.imrmc[i, "caseID"])
}
index <- order(dFrame.imrmc[, "caseID"])
dFrame.imrmc <- dFrame.imrmc[index, ]



# Process data ###############################################################

# Analyze the MRMC ROC data using new R code
# Processing time before BDG
# user  system elapsed 
# 3.36    0.81    4.17

source(file.path("R", "iMRMC_R.R"))
start.time <- proc.time()
system.time({
  result_doIMRMC_current <- doIMRMC_R(dFrame.imrmc)
})
end.time <- proc.time()
print("Runtime for R code")
print(end.time - start.time)



# Analyze the MRMC ROC data with java code
# Processing time
# user  system elapsed 
# 0.07    0.04    3.17
start.time <- proc.time()
system.time({
  result_doIMRMC_target <- iMRMC::doIMRMC(dFrame.imrmc)
})
end.time <- proc.time()
print("Runtime for java code")
print(end.time - start.time)



# perReader output full #############################################
# The target result has 28 variables/columns
# Variables 15 through 28 of target results are NA
target <- result_doIMRMC_target$perReader[,4:14]
index.delete <- target$N0 >= 2
target <- target[index.delete, ]
index.delete <- target$N1 >= 2
target <- target[index.delete, ]
rownames(target) <- NULL
current <- result_doIMRMC_current$perReader

# Java code has 8 digits significance
# R code has 10 digits significance
# The reason is that the Java function reads and writes files.  
testthat::test_that(
  "doIMRMC perReader output does not change", {
    testthat::expect_equal(target, current,tolerance = 1e-6)
  }
)



# Ustat output ###############
target = result_doIMRMC_target$Ustat[,4:24]
current = result_doIMRMC_current$Ustat

testthat::test_that(
  "doIMRMC Ustat output does not change", {
    testthat::expect_equal(target, current)
  }
)



# MLEstat output ###############
target = result_doIMRMC_target$MLEstat[,4:24]
current = result_doIMRMC_current$MLEstat

testthat::test_that(
  "doIMRMC Ustat output does not change", {
    testthat::expect_equal(target, current)
  }
)



# varDecomp$BDG #############################################################
target <- result_doIMRMC_target$varDecomp$BDG
current <- result_doIMRMC_current$varDecomp$BDG

testthat::test_that(
  "doIMRMC varcomp-BDG output does not change", {
    testthat::expect_equal(target, current,tolerance = 1e-4)
  }
)



# varDecomp$BCK #############################################################
target <- result_doIMRMC_target$varDecomp$BCK
current <- result_doIMRMC_current$varDecomp$BCK

testthat::test_that(
  "doIMRMC varcomp-BDG output does not change", {
    testthat::expect_equal(target, current,tolerance = 1e-4)
  }
)



# ROC ###############
target <- result_doIMRMC_target$ROC
current <- result_doIMRMC_current$ROC

# ROC per-reader visual test
plot(current$testA.reader2$fpf,
     current$testA.reader2$tpf, type = "l")
lines(target$`testA: reader2`$fpf,
      target$`testA: reader2`$tpf, lty = 2)

# ROC pooled-readers visual test
plot(current$testA.pooled$fpf,
     current$testA.pooled$tpf, type = "l")
lines(target$`testA: Pooled Average`$fpf,
      target$`testA: Pooled Average`$tpf, lty = 2)

# ROC diagonal average visual test
plot(current$testA.diagonalAvg$fpf,
     current$testA.diagonalAvg$tpf, type = "l")
lines(target$`testA: Diagonal Average`$fpf,
      target$`testA: Diagonal Average`$tpf, lty = 2)

# ROC vertical average visual test
plot(current$testA.verticalAvg$fpf,
     current$testA.verticalAvg$tpf, type = "l")
lines(target$`testA: Vertical Average`$fpf,
      target$`testA: Vertical Average`$tpf, lty = 2)

# ROC horizontal average test
plot(current$testA.horizontalAvg$fpf,
     current$testA.horizontalAvg$tpf, type = "l")
lines(target$`testA: Horizontal Average`$fpf,
      target$`testA: Horizontal Average`$tpf, lty = 2)



