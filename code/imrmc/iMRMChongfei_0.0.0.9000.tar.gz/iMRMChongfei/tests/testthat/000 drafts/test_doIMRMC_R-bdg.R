library(iMRMC)
library(iMRMChongfei)
library(testthat)

context("doIMRMC_R")

# initialize the random number generator
iMRMC::init.lecuyerRNG()

# Create a sample configuration file
config <- iMRMC::sim.gRoeMetz.config()

# Simulate an MRMC ROC data set
dFrame.imrmc <- iMRMC::sim.gRoeMetz(config)

# Analyze the MRMC ROC data with java code
system.time({
  result_java <- iMRMC::doIMRMC(dFrame.imrmc)
})

## Analyze the MRMC ROC data using new R code
system.time({
  result_R <- doIMRMC_R(dFrame.imrmc)
})



#### test perReader output ###############
# [1] "inputFile"        "date"             "iMRMCversion"

# [4] "readerID"         "N0"               "N1"
# [7] "modalityA"        "modalityB"        "AUCA"             "varAUCA"          "AUCB"             "varAUCB"
# [13] "AUCAminusAUCB"    "varAUCAminusAUCB"

# [15] "pValueNormal"     "botCInormal"      "topCInormal"      "rejectNormal"
# [19] "dfBDG"            "pValueBDG"        "botCIBDG"         "topCIBDG"         "rejectBDG"        "dfHillis"
# [25] "pValueHillis"     "botCIHillis"      "topCIHillis"      "rejectHillis"

# Notice the columns that we compare
# Future work should produce the results for columns 15-23
# Future work should produce the reader by modality covariance matrix
target <- result_java$perReader[,4:14]
current <- result_R$perReader

# Do the comparison
test_that(
  "doIMRMC perReader output does not change", {
    expect_equal(target, current)
  }
)



#### test Ustat output ###############
# [1] "inputFile"        "date"             "iMRMCversion"

# [4] "NR"               "N0"               "N1"
# [7] "modalityA"        "modalityB"        "UstatOrMLE"       "AUCA"             "varAUCA"          "AUCB"
# [13] "varAUCB"          "AUCAminusAUCB"    "varAUCAminusAUCB" "pValueNormal"     "botCInormal"      "topCInormal"
# [19] "rejectNormal"     "dfBDG"            "pValueBDG"        "botCIBDG"         "topCIBDG"         "rejectBDG"

# [25] "dfHillis"         "pValueHillis"     "botCIHillis"      "topCIHillis"      "rejectHillis"

# Notice the columns that we compare
target <- result_java$Ustat[,4:24]
current <- result_R$Ustat

test_that(
  "doIMRMC Ustat output does not change", {
    expect_equal(target, current)
  }
)



#### test MLEstat output ###############
# [1] "inputFile"        "date"             "iMRMCversion"

# [4] "NR"               "N0"               "N1"
# [7] "modalityA"        "modalityB"        "UstatOrMLE"       "AUCA"             "varAUCA"          "AUCB"
# [13] "varAUCB"          "AUCAminusAUCB"    "varAUCAminusAUCB" "pValueNormal"     "botCInormal"      "topCInormal"
# [19] "rejectNormal"     "dfBDG"            "pValueBDG"        "botCIBDG"         "topCIBDG"         "rejectBDG"

# [25] "dfHillis"         "pValueHillis"     "botCIHillis"      "topCIHillis"      "rejectHillis"

# Notice the columns that we compare
target <- result_java$MLEstat[,4:24]
current <- result_R$MLEstat

test_that(
  "doIMRMC Ustat output does not change", {
    expect_equal(target, current)
  }
)



## test varDecomp$BCK  ########
target <- result_java$varDecomp$BCK
current <- result_R$varDecomp$BCK

test_that(
  "doIMRMC varcomp-BCK output does not change", {
    expect_equal(target, current,tolerance = 1e-6)
  }
)

## test varDecomp$BDG  ########
target <- result_java$varDecomp$BDG
current <- result_R$varDecomp$BDG

test_that(
  "doIMRMC varcomp-BDG output does not change", {
    expect_equal(target, current,tolerance = 1e-6)
  }
)



#### test ROC output ###############
# target <- capture.output(str(result_java$ROC))
# current <- capture.output(str(result_R$ROC))
target <- result_java$ROC
current <- result_R$ROC

# target has attributes
# As these are not data, we strip them out of the test
# attr(result_java$ROC, "dim") <- NULL
# attr(result_java$ROC, "call") <- NULL
# attr(result_java$ROC, "class") <- NULL

# names(current) <- NULL

# This shows there three differences that are worse than the rest
test_that(
  "doIMRMC ROC output does not change", {
    expect_equal(target, current, tolerance = 1e-4)
  }
)

# PROBLEM WITH ROC CURVES#####

# Let's look at fpf differences
# We will find a serious problem for
#    i=2  "desc testA: Horizontal Average"
#    i=11 "desc testB: Horizontal Average"

# THE PROBLEM IS WITH CURRENT=OLD

# All other cases beat tolerance 1e-5
# All single reader data is identical
for (i in 1:length(target)) {
  
  target.1 <- target[[i]]
  current.1 <- current[[i]]
  
  temp <- data.frame(target.1$fpf, current.1$fpf, target.1$fpf - current.1$fpf)
  print(temp)
  print(paste("desc", target.1$desc))
  print(paste("max", max(abs(temp[ , 3])), "position", which.max(abs(temp[ , 3]))))
  print(paste("i", i))
  
  browser()
}

# Let's look at tpf differences
# We will find a serious problem for
#    i=9  "desc testA: Vertical Average"

# THIS IS A PROBLEM WITH TARGET=NEW DOES NOT ACHIEVE 1.0

# All other cases beat tolerance 1e-5
# All single reader data is identical
for (i in 1:length(target)) {
  
  target.1 <- target[[i]]
  current.1 <- current[[i]]
  
  temp <- data.frame(target.1$tpf, current.1$tpf, target.1$tpf - current.1$tpf)
  print(temp)
  print(paste("desc", target.1$desc))
  print(paste("max", max(abs(temp[ , 3])), "position", which.max(abs(temp[ , 3]))))
  print(paste("i", i))
  
  browser()
}