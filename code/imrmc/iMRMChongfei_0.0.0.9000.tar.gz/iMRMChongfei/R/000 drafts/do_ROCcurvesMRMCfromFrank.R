#This is a collection of convenient ROC routines written by Frank Samuelson

normAUCfromSeSp=function(se,sp){ #estimate of AUC from se,sp for Gaussian
	pnorm( (qnorm(sp)-qnorm(1-se))/sqrt(2))
}

plAUCfromSeSp=function(se,sp){ #estimate of AUC from se,sp for power-law
  l=log(se)/log(1-sp)
  1/(1+l)
}

snrEst=function(x0,x1)   # Signal to noise estimate (Gaussian)
        return ((mean(x1)-mean(x0))/ sqrt(var(x0)+var(x1)))

ROCxy<-function(sa,sp) {  # (x,y) Points for an ROC curve.
  # sa are the signal absent ratings.  sp are the signal present ratings
  lvls<-sort(unique(c(sa,sp)),decreasing=T)
  return(list(x=c(0,cumsum(table(factor(sa,levels=lvls)))/length(sa)),
              y=c(0,cumsum(table(factor(sp,levels=lvls)))/length(sp))))
}

HanleyMcNeil=function(auc,n0,n1) {
        # The very good power-law variance estimate from Hanley/McNeil
		  # based on just the AUC value, and the sample sizes, n0,n1
        auc2=auc*auc
        q1=auc/(2.-auc)
        q2=2.*auc2/(1.+auc)
        return( (auc-auc2+(n1-1.)*(q1-auc2)+(n0-1.)*(q2-auc2))/n0/n1 )
}

aVeryApproximateAUCvariance=function(auc,n0,n1)
    auc*(1-auc)/ ( n0*n1/(n0+n1))/3  # Not great at high AUC.


AUCfromxy = function( roc) {  
   # This function takes an x,y list of points that make an ROC curve
   # (like one that comes from ROCxy())  and returns the area under
   # that curve.
   return(sum( diff(roc$x)*(diff(roc$y)/2+roc$y[-length(roc$y)]),na.rm=T))
}

AUC = function (p1,a1) {   
  # Arguments: a1 is a vector of the signal absent scores.
  #            p1 is a vector of the signal present scores.
  # This function returns the empirical AUC estimate
  nop=length(p1)      # Number of actually positive cases
  empa=(sum(rank(c(p1,a1))[0:nop])- nop*(nop+1)/2)/nop/length(a1)
  empa   # return empirical auc
}


AuROC<-function(sa,sp) {  #empirical Area under ROC/ Wilcoxon-Mann-.... stat.
  # Also calculate the approx empirical variance thereof.  Goes as O(n*log(n)).
  # Written by Frank W. Samuelson for the FDA, 2004.
  
  nx<-length(sa);
  ny<-length(sp);
  nall<-nx+ny;
  rankall<-rank(c(sa,sp)) # rank of all samples with respect to one another.
  
  ranksp<-rankall[(nx+1):nall];    # ranks of the sp cases
  ranksum <-sum(ranksp)-ny*(ny+1)/2 #sum of ranks of sp among sas.

  ranky<-rank(sp); ## ranks of just the y's (present) among themselves
  rankyx<-ranksp-ranky    # ranks of the y's among the x's (sa)
  p21<-sum(rankyx*rankyx-rankyx)/nx/(nx-1)/ny; #term in variance

  rankx<-rank(sa);  ## ranks of x's (sa) among each other
  ## reverse ranks of x's with respect to y's.
  rankxy<- ny- rankall[1:nx]+ rankx ;
  p12<- sum(rankxy*rankxy-rankxy)/nx/ny/(ny-1); #another variance term

  a<-ranksum/ny/nx;       # the empirical area
  v<-(a*(1-a)+(ny-1)*(p12-a*a) + (nx-1)*(p21-a*a))/nx/ny;

  ## Var approximation
  neff= 2/(1/nx+1/ny)
  apv=a*(1-a)/(2*neff)

  c(a,v,apv);  # return vector containing Mann-Whitney stat and the variance.
}

unbiasedMeanMatrixVar=function(sm){
    n=nrow(sm);m=ncol(sm);
    auc=mean(sm)
    x0est=colMeans(sm)
    x1est=rowMeans(sm)
    MST=var(as.vector(sm))
    MSA=m*var(x1est)
    MSB=n*var(x0est)
    ev=((n*m-1)*MST-(n-1)*MSA-(m-1)*MSB)/((n-1)*(m-1))
    siga=(MSA-ev)/m; sigb=(MSB-ev)/n
    vout=(MSA+MSB-ev)/(m*n)
    c(auc,vout)
}
  
MWWStatVar=function(y,x,y0=NA,x0=NA,deLong=F){
  # This function returns the empirical AUC statistic and its unbiased, 
  # non-negative variance estimate. Arguments y and x are the two samples.
  # If y0 and x0 are provided, the difference of two AUC
  # statistics and the variance estimate of that difference is output.
  # There is an option to give deLong estimate rather than unbiased.
  k <- function(x,y) (sign(y-x)+1)/2;  # The indicator kernel function
  m <- length(y); n <- length(x);  X <- outer(x,y,k);
  if (length(y)==length(y0) && length(x)==length(x0)) X<- X-outer(x0,y0,k)
  MSA <- m*var(rowMeans(X)) ;  MSB <- n*var(colMeans(X)) ;  
  MST <- var(as.vector(X))
  ev <- ifelse(deLong, 0, ((n*m-1)*MST-(n-1)*MSA-(m-1)*MSB)/((n-1)*(m-1)))
  return(c(mean(X), (MSA+MSB-ev)/(m*n)))
}


avROCdata=function(ldata, direction="SeSp") {
   ## This function takes a list of pairs of score data and 
   ## calculates an average ROC curve.
   ## ldata= list( list(abs1,sig1), list(abs2,sig2), list(....),...)
   ## where sig are signal present scores and 
   ## abs are signal absent scores

   ## "direction" is the direction over which you want to average 
   ## the curves.
   ## direction="Se" means that the ROC curves of the data sets
   ##                are averaged in sensitivity at every possible specificity.
   ##                The ROC curves are averaged vertically.
   ## direction="Sp" means that the ROC curves of the data sets
   ##                are averaged in specificity at every possible specificity
   ##                The ROC curves are averaged horizontally.
   ## direction="SeSp" means that the ROC curves of the data sets
   ##                are averaged in Se+Sp at every possible Se-Sp.
   ##                The ROC curves are averaged diagonally.

     ## First generate an ROC curve for each data set
     rocs=lapply(ldata, function(i) as.data.frame(ROCxy(i[[1]],i[[2]])))
     ## Calculate the average ROC curve of all those data sets.
     return(avROC(rocs,direction=direction))
}

avROC=function( rocs, direction="SeSp") {
   # This function takes a list of ROC curves, such as those
   # that come from ROCxy, and takes the mean of them.
   e= 9*.Machine$double.eps

   #print(rocs)

   ## Loop over ROC curves, rotating them depending upon 
   ## direction of averaging.
   rotrocs=lapply(rocs, function(roc) {
      if (direction=="SeSp") {
         return(data.frame(u=(roc$x+roc$y)/2.,
                           v=(roc$y-roc$x)/2.))
      } else if (direction=="Se") {
         ret=data.frame(u=roc$x, v=roc$y)
      } else {
         ret=data.frame( u=roc$y, v=roc$x)
      }
      # Eliminate redundant "vertical" points for approx()
      ret=do.call(rbind,by(ret,ret$u,function(i) {
                  if (nrow(i)<2) return(i)
                  top=i[which.max(i$v),]
                  if (top$u< 1.) top$u=top$u+e
                  bottom=i[which.min(i$v),]
                  if (bottom$u>0.) bottom$u=bottom$u-e
                  return(rbind(top,bottom))
      }))
      #print(ret)
      return(ret)
   })
   # Collect ordinate values at which we will 
   # approximate the mean ROC curve
   stdA=c()
   for (i in rotrocs) stdA=c(stdA,i$u)
   stdA=sort(unique(stdA))


   ## Interpolate all points on all ROC curves.
   approtrocs=lapply(rotrocs, function(roc) 
      approx(roc$u,roc$v,stdA))

   ## Calculate the average ROC curve.
   ymean=rep(0,length(stdA))  
   for (i in approtrocs)  ymean=ymean+i$y
   ymean=ymean/length(approtrocs)

   # Rotate our average ROC curve back to the usual Se(Sp) space.
   if (direction=="SeSp"){
      fpout=stdA-ymean
      tpout=stdA+ymean
   } else if (direction=="Se"){
      tpout=c(0,ymean,1)
      fpout=c(0,stdA,1)
   } else {
      tpout=c(0,stdA,1)
      fpout=c(0,ymean,1)
   }
   # Return the x,y points of the average ROC curve
   return(data.frame(x=fpout,y=tpout)) 
}

testROCaverage=function(){
    rocdata=list(  # make 3 random ROC data sets
        rocdata1=list(rnorm(78),rnorm(67)+1.5),
        rocdata2=list(rnorm(58),rnorm(83)+1.6),
        rocdata3=list(rexp(128),rexp(119,1/5))
    )

    # Plot the ROC curves
    plot(0,0,type='n',xlim=c(0,1),ylim=c(0,1),xlab="FPF",ylab="TPF")
    aucs=sapply(rocdata, function(d) {
        lines(ROCxy(d[[1]],d[[2]]))
        AUC(d[[2]],d[[1]])
    })
    
    AvCurve=avROCdata(rocdata, direction="SeSp")
    lines(AvCurve,col=2)   # plot the Average curve in red.

    print( paste("AUCs are ", paste(aucs,collapse=" ")))
    print( paste("mean of AUCs is ", mean(aucs)))
    print( paste("AUC under average curve is ", AUCfromxy(AvCurve)))

}
