#' MRMC analysis for arbitray design dataset
#'
#'
#'
#' @description This function takes arbitray design MRMC data frame and runs a multi-reader multi-case analysis
#' based on on U-statistics as described in the following papers:
#' Gallas2006_Acad-Radiol_v13p353 (single-modality),
#' Gallas2008_Neural-Networks_v21p387 (multiple modalities, arbitrary study designs),
#' Gallas2009_Commun-Stat-A-Theor_v38p2586 (framework paper).
#'
#'
#'
#'
#'
#' @param data character string or data frame containing the following variables:
#' \itemize{
#'   \item \code{readerID, Factor} with levels like "reader1", "reader2", ...
#'   \item \code{caseID, Factor} with levels like "case1", "case2", ...
#'   \item \code{modalityID, Factor} with levels like "modality1", "modality2", ...
#'   \item \code{score, num} reader score
#' }
#'
#' If data is a character string, it is a file name in the .imrmc format.
#'
#' Each row of this data frame corresponds to an observation.
#' For every caseID, there must be a row corresponding to the truth observation.
#' The readerID for a truth observation is "truth".
#' The modalityID for a truth observation is "truth".
#' The score for a truth observation must be either 0 (signal-absent) or 1 (signal-present).
#'
#' @return The MRMC analysis results, below is a quick summary:
#'
#'
#'
#' \itemize{
#'   \item {\code{perReader, data.frame}
#'    this data frame contains the performance results for each reader.
#'              Key variables of this data frame are AUCA, AUCB, AUCAminusAUCB and the corresponding
#'              variances, confidence intervals, degrees of freedom and p-values.}
#'   \item {\code{Ustat, data.frame}
#'    this data frame contains the reader-average performance results.
#'              The analysis results are based on U-statistics and the papers listed above.
#'              Key variables of this data frame are AUCA, AUCB, AUCAminusAUCB and the corresponding
#'              variances, confidence intervals, degrees of freedom and p-values.}
#'   \item {\code{MLEstat, data.frame}
#'    this data frame contains the reader-average performance results.
#'              The analysis results are based on V-statistics, which approximates the true distribution with
#'              the empirical distribution. The empirical distribution equals the nonparametric MLE
#'              estimate of the true distribution, which is also equivalent to the ideal bootstrap estimate.
#'              Please refer to the papers listed above.
#'              Key variables of this data frame are AUCA, AUCB, AUCAminusAUCB and the corresponding
#'              variances, confidence intervals, degrees of freedom and p-values.
#'   }
#'   \item {\code{ROC, list}
#'    each object of this list is an object containing an ROC curve.
#'              There is an ROC curve for every combination of reader and modality.
#'              For every modality, there are also four average ROC curves. These are discussed in
#'                Chen2014_Br-J-Radiol_v87p20140016.
#'                The diagonal average averages the reader-specific ROC curves along y = -x + b for b in (0,1).
#'                The horizontal average averages the reader specific ROC curves along y = b for b in (0,1).
#'                The vertical average averages the reader specific ROC curves along x = b for b in (0,1).
#'                The pooled average ignores readerID and pools all the scores together to create one ROC curve.
#'   }
#' }
#'
#'
#' @export
#@examples
#'
#'
doIMRMC_R_arbitrary = function(data){
  
  # initialize and check the data #############################################
  
  # If data is character, it is a file name. Read in data.
  if (class(data) == "character") {
    
    # Open and read the file.
    conn <- file(data, open = "r")
    desc <- readLines(conn)
    
    # Find the line number of "BEGIN DATA:". The lines following are the data.
    skipIndex <- grep("BEGIN DATA:", desc)
    close(conn)
    
    # This file is expected to be .imrmc format
    data <- read.csv(data, header = FALSE, skip = skipIndex,
                     col.names = c("readerID", "caseID", "modalityID", "score"),
                     colClasses = c("factor", "factor", "factor", "numeric"))
    
  }


    
  # Factorize readerID, caseID, and modalityID
  data$readerID <- factor(data$readerID)
  data$caseID <- factor(data$caseID)
  data$modalityID <- factor(data$modalityID)
  
  
  
          # # Initialize modalities
          # modalities <- levels(data$modalityID)
          # # Trim leading and trailing white space from modalities
          # modalities <- trimws(modalities)
          # 
          # # Check that one of the modalities is "truth".
          # # If yes, remove it from the modalities.
          # # If no, throw an error.
          # if ("truth" %in% modalities) {
          #   modalities <- modalities[modalities != "truth"]
          #   nM <- length(modalities)
          # } else {
          #   stop(paste("\n  There is no truth modality."))
          # }
          # 
          # # Check that there are only two modalities.
          # if (nM != 2) {
          # 
          #   stop("
          #   This function currenly only treats two modalities.
          #   The data provided does not have two modalities.
          #   We need to update this function to treat one modality.
          #   We need a wrapper function to treat more than one modality.
          #        ")
          # 
          # }
          # 
          # 
          # 
          # # Initialize readers
          # readers = levels(data$readerID)
          # # Trim leading and trailing white space from readers
          # readers <- trimws(readers)
          # 
          # # Check that one of the readers is "truth".
          # # If yes, remove it from the modalities
          # # If no, throw an error.
          # if ("truth" %in% readers) {
          #   readers <- readers[readers != "truth"]
          #   nR <- length(readers)
          # } else {
          #   stop(paste("\n  There is no truth reader"))
          # }
          # 
          # 
          # 
          # # Split the data into truth and not truth data frames
          # truth <- data[data$modalityID == "truth", ]
          # truth$readerID <- factor(truth$readerID)
          # truth$caseID <- factor(truth$caseID)
          # truth$modalityID <- factor(truth$modalityID)
          # 
          # mrmcDF <- data[data$modalityID != "truth", ]
          # mrmcDF$readerID <- factor(mrmcDF$readerID)
          # mrmcDF$caseID <- factor(mrmcDF$caseID)
          # mrmcDF$modalityID <- factor(mrmcDF$modalityID)
          # 
          # 
          # 
          # # Check that all the data has truth.
          # # If not, throw an error.
          # index.TF <- !(levels(mrmcDF$caseID) %in% levels(truth$caseID))
          # if (any(index.TF)) {
          # 
          #   print("These cases do not have truth")
          #   print(levels(mrmcDF$caseID)[index.TF])
          #   stop("\n  Not all cases have truth")
          # 
          # }
          # 
          # 
          # 
          # # Check that each case only has one truth
          # index.TF <- duplicated(truth$caseID)
          # if (any(index.TF)) {
          # 
          #   print("These cases are duplicated")
          #   print(truth$caseID[index.TF])
          #   stop("\n Some cases have more than one definition of truth.")
          # }
          # 
          # 
          # 
          # # Initialize case info
          # cases.neg = factor(truth[truth$score == 0, "caseID"])
          # nC.neg = nlevels(cases.neg)
          # 
          # cases.pos = factor(truth[truth$score == 1, "caseID"] )
          # nC.pos = length(cases.neg)

  
  
  # Initialize modalities
  modalities <- levels(data$modalityID)
  # Trim leading and trailing white space from modalities
  modalities <- trimws(modalities)
  
  # Check that one of the modalities is "truth".
  # If not, throw an error.
  if (!("truth" %in% modalities)) {
    stop(paste("\n  There is no truth modality."))
  } else {
    modalities <- modalities[modalities != "truth"]
  }
  
  
  
  
  # modalities=levels(data$modalityID)[-1]
  readers = levels(data$readerID)[-1]
  nR = length(levels(data$readerID)) - 1
  
  #nC.neg = (data %>% filter(modalityID == 'truth'& score == 0) %>% dim())[1]
  #nC.pos = (data %>% filter(modalityID == 'truth'& score == 1) %>% dim())[1]
  #browser()
  truth.neg = data[(data$modalityID == 'truth' & data$score == 0), ] 
  nC.neg = nrow(truth.neg)
  
  truth.pos = data[(data$modalityID == 'truth' & data$score == 1), ] 
  nC.pos = nrow(truth.pos)
  
  nm = length(levels(data$modalityID)) - 1
  try(if (nm != 2) stop("Only work for two modalities"))
  s_m = success_matrix_arbitrary(data)
  AUC_per_avg_out = AUC_varAUC_arbitrary(data,s_m)

  BDG_coef = AUC_per_avg_out[[7]]
  BCK_coef = AUC_per_avg_out[[8]]

  ######################### perReader #######################################################################
 
  ## calculate the Ustat covariance
  AUC_cov_out = AUC_cov_arbitrary(s_m)
  BCK_cov_coef =  AUC_cov_out[[9]]
  BDG_cov_coef =  AUC_cov_out[[8]]
  ## Variance for averaged AUCA-AUCB
  Ustat_dif_var = sum(AUC_per_avg_out[[2]]$Ustat_var) - 2*AUC_cov_out[[2]]

  ## Variance for per reader AUCA-AUCB

  
  perReader_output = AUC_per_avg_out[[1]]
  Ustat_pereader_dif_var = perReader_output[perReader_output$modality == modalities[1], ]['varAUC'] + 
                           perReader_output[perReader_output$modality == modalities[2], ]['varAUC'] -
                           2*AUC_cov_out[[1]]
  
  ## difference of AUC between two modalities per reader
  
  dif_perReader = perReader_output[perReader_output$modality == modalities[1], ]$AUC_est -
                  perReader_output[perReader_output$modality == modalities[2], ]$AUC_est
                  
  

  ## Create the data frame to stroe per Reader output
  
  perReader = data.frame(inputFile = rep("input.imrmc",(nm + 1)*nR) ,
                         date = rep(Sys.Date(),(nm + 1)*nR),
                         MRMC_R_Version = rep("Version 0.0.9", (nm + 1)*nR),
                         readerID = rep(paste0("reader",1:nR),nm + 1),
                         N0 = c(as.vector(t(s_m[[3]][,1,])),s_m[[4]][2,]),
                         N1 = c(as.vector(t(s_m[[3]][,2,])),s_m[[4]][1,]),
                         modalityA = c(rep(modalities,each = nR),rep(modalities[1],nR)),
                         modalityB = c(rep("NO_MOD",nR*nm),rep(modalities[2],nR)),
                         AUCA = c(AUC_per_avg_out[[1]][,3],AUC_per_avg_out[[1]][1:nR,3]),
                         varAUCA = c(AUC_per_avg_out[[1]][,4],AUC_per_avg_out[[1]][1:nR,4]),
                         AUCB = c(rep(NA,nR*nm),AUC_per_avg_out[[1]][(nR + 1):(nR*nm),3]),
                         varAUCB = c(rep(NA,nR*nm),AUC_per_avg_out[[1]][(nR + 1):(nR*nm),4]),
                         AUCAminusAUCB = c(rep(NA,nR*nm),dif_perReader),
                         varAUCAminusAUCB = c(rep(NA,nR*nm),Ustat_pereader_dif_var[1:nR,]))
  ####################################################################################################


  ######################### Ustat ####################################################################

  ## Based on the paper below
  ## https://github.com/DIDSR/DevinHFD/blob/master/Papers/Obuchowski2012_Acad-Radiol_v19p1508.pdf
  
  ## DF calculation
  
  DFreaderA = round((1/BCK_coef[,4] - 1)[1])
  DFreaderB = round((1/BCK_coef[,4] - 1)[2])
  DFnormalA = round((1/BCK_coef[,1] - 1)[1])
  DFnormalB = round((1/BCK_coef[,1] - 1)[2])
  DFdiseaseA = round((1/BCK_coef[,2] - 1)[1])
  DFdiseaseB = round((1/BCK_coef[,2] - 1)[2])
  
  
  DFnormal = min(DFnormalA,DFnormalB)
  DFdisease = min(DFdiseaseA,DFdiseaseB)
  DFreader = min(DFreaderA,DFreaderB)
  
  
  ## For difference of AUCA-AUCB
  st_normal = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2])/sqrt(Ustat_dif_var)

  p_normal_A_B = (1 - pnorm(abs(st_normal)))*2



  botCInormal_A_B = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]) - qnorm(0.975)*sqrt(Ustat_dif_var)


  topCInormal_A_B = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]) + qnorm(0.975)*sqrt(Ustat_dif_var)

  
  sbr = (sum(AUC_per_avg_out[[6]][,4]) - 2*AUC_cov_out[[7]][4])^2/(DFreader)^3 #(nR-1)^3
  sb0 = (sum(AUC_per_avg_out[[6]][,1]) - 2*AUC_cov_out[[7]][1])^2/(DFnormal)^3 #(nC.neg-1)^3
  sb1 = (sum(AUC_per_avg_out[[6]][,2]) - 2*AUC_cov_out[[7]][2])^2/(DFdisease)^3 #(nC.pos-1)^3

  # sbr=(sum(AUC_per_avg_out[[6]][,4])-2*AUC_cov_out[[7]][4])^2/(1/BCK_cov_coef[4]-1)^3 #(nR-1)^3
  # sb0=(sum(AUC_per_avg_out[[6]][,1])-2*AUC_cov_out[[7]][1])^2/(1/BCK_cov_coef[1]-1)^3 #(nC.neg-1)^3
  # sb1=(sum(AUC_per_avg_out[[6]][,2])-2*AUC_cov_out[[7]][2])^2/(1/BCK_cov_coef[2]-1)^3 #(nC.pos-1)^3

  # sbr=(sum(AUC_per_avg_out[[6]][,4])-2*AUC_cov_out[[7]][4])^2/(nR-1)^3
  # sb0=(sum(AUC_per_avg_out[[6]][,1])-2*AUC_cov_out[[7]][1])^2/(nC.neg-1)^3
  # sb1=(sum(AUC_per_avg_out[[6]][,2])-2*AUC_cov_out[[7]][2])^2/(nC.pos-1)^3
  dfBDG_A_B = Ustat_dif_var^2/(sbr + sb1 + sb0)


  df_min = min(DFnormal,DFdisease,DFreader)
  
  if (dfBDG_A_B < df_min) {
    print(paste0("DF_BDG is below a minimum.",
                 "DF_BDG was calculated to be ", dfBDG_A_B, "It is being set to DF_min = ",df_min,
                 "This follows Gaylor1969_Technometrics_v4p691",
                 "and indicates that your data is very limited"))
    dfBDG_A_B = df_min}
  
  
  
  if (dfBDG_A_B < 2) {
    print(paste0("DF_BDG is below a minimum.",
                 "DF_BDG was calculated to be ", dfBDG_A_B, "DF_BDG less than 2 cannot be handled.
                 Therefore, it is being set to 2"))
    dfBDG_A_B = 2}
  
  if (dfBDG_A_B >= 50) {
    p_BDG_A_B = p_normal_A_B
    botCIBDG_A_B = botCInormal_A_B
    topCIBDG_A_B = topCInormal_A_B
     
  }
  else{
  p_BDG_A_B = (1 - pt(abs(st_normal),df = floor(dfBDG_A_B)))*2


  botCIBDG_A_B = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]) - qt(0.975,df = floor(dfBDG_A_B))*sqrt(Ustat_dif_var)


  topCIBDG_A_B = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]) + qt(0.975,df = floor(dfBDG_A_B))*sqrt(Ustat_dif_var)
  }
  

  ## FOr AUCA


  st_normal = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - 0.5)/sqrt(AUC_per_avg_out[[2]]$Ustat_var[1])


  p_normal_A = (1 - pnorm(abs(st_normal)))*2



  botCInormal_A = (AUC_per_avg_out[[2]]$AvgAUC_est[1]) - qnorm(0.975)*sqrt(AUC_per_avg_out[[2]]$Ustat_var[1])


  topCInormal_A = (AUC_per_avg_out[[2]]$AvgAUC_est[1]) + qnorm(0.975)*sqrt(AUC_per_avg_out[[2]]$Ustat_var[1])

  # sbr=(AUC_per_avg_out[[6]][1,4])^2/(nR-1)^3
  # sb0=(AUC_per_avg_out[[6]][1,1])^2/(nC.neg-1)^3
  # sb1=(AUC_per_avg_out[[6]][1,2])^2/(nC.pos-1)^3
  

  sbr = (AUC_per_avg_out[[6]][1,4])^2/DFreaderA^3
  sb0 = (AUC_per_avg_out[[6]][1,1])^2/DFnormalA^3
  sb1 = (AUC_per_avg_out[[6]][1,2])^2/DFdiseaseA^3
  
  dfBDG_A = AUC_per_avg_out[[2]]$Ustat_var[1]^2/(sbr + sb1 + sb0)
 
  # sd=0
  # for (i in 1:7){
  #
  #    sd=sd+(AUC_per_avg_out[[6]][1,i])^2/(1/BCK_coef[,i])[1]^2/(1/BCK_coef[,i]-1)[1]
  #
  #  }
  #
  # dfBDG_A=AUC_per_avg_out[[2]]$Ustat_var[1]^2/sd

  df_min = min(DFnormalA,DFdiseaseA,DFreaderA)

  if (dfBDG_A < df_min) {
    print(paste0("DF_BDG is below a minimum.",
            "DF_BDG was calculated to be ", dfBDG_A, "It is being set to DF_min = ",df_min,
            "This follows Gaylor1969_Technometrics_v4p691",
            "and indicates that your data is very limited"))
    dfBDG_A = df_min}
  
  
  
  if (dfBDG_A < 2) {
    print(paste0("DF_BDG is below a minimum.",
                 "DF_BDG was calculated to be ", dfBDG_A, "DF_BDG less than 2 cannot be handled.
                 Therefore, it is being set to 2"))
    dfBDG_A = 2}
  
  
  if (dfBDG_A >= 50) {
    p_BDG_A = p_normal_A
    botCIBDG_A = botCInormal_A
    topCIBDG_A = topCInormal_A
  }
  else{

  p_BDG_A = (1 - pt(abs(st_normal),df = floor(dfBDG_A)))*2


  botCIBDG_A = (AUC_per_avg_out[[2]]$AvgAUC_est[1]) - qt(0.975,df = floor(dfBDG_A))*sqrt(AUC_per_avg_out[[2]]$Ustat_var[1])


  topCIBDG_A = (AUC_per_avg_out[[2]]$AvgAUC_est[1]) + qt(0.975,df = floor(dfBDG_A))*sqrt(AUC_per_avg_out[[2]]$Ustat_var[1])
  }


  ## For AUCB


  st_normal = (AUC_per_avg_out[[2]]$AvgAUC_est[2] - 0.5)/sqrt(AUC_per_avg_out[[2]]$Ustat_var[2])


  p_normal_B = (1 - pnorm(abs(st_normal)))*2



  botCInormal_B = (AUC_per_avg_out[[2]]$AvgAUC_est[2]) - qnorm(0.975)*sqrt(AUC_per_avg_out[[2]]$Ustat_var[2])


  topCInormal_B = (AUC_per_avg_out[[2]]$AvgAUC_est[2]) + qnorm(0.975)*sqrt(AUC_per_avg_out[[2]]$Ustat_var[2])


  sbr = (AUC_per_avg_out[[6]][2,4])^2/DFreaderB^3
  sb0 = (AUC_per_avg_out[[6]][2,1])^2/DFnormalB^3
  sb1 = (AUC_per_avg_out[[6]][2,2])^2/DFdiseaseB^3

  # sbr=(AUC_per_avg_out[[6]][2,4])^2/(nR-1)^3
  # sb0=(AUC_per_avg_out[[6]][2,1])^2/(nC.neg-1)^3
  # sb1=(AUC_per_avg_out[[6]][2,2])^2/(nC.pos-1)^3

  dfBDG_B = AUC_per_avg_out[[2]]$Ustat_var[2]^2/(sbr + sb1 + sb0)
  ## calculate df of BDG
  # sd=0
  # #
  # for (i in 1:7){
  #
  #    sd=sd+(AUC_per_avg_out[[6]][2,i])^2/(1/BCK_coef[,i])[2]^2/(1/BCK_coef[,i]-1)[2]
  #  }
  #
  # dfBDG_B=AUC_per_avg_out[[2]]$Ustat_var[2]^2/sd

  df_min = min(DFnormalB,DFdiseaseB,DFreaderB)

  if (dfBDG_B < df_min) {
    print(paste0("DF_BDG is below a minimum.",
                 "DF_BDG was calculated to be ", dfBDG_B, "It is being set to DF_min = ",df_min,
                 "This follows Gaylor1969_Technometrics_v4p691",
                 "and indicates that your data is very limited"))
    dfBDG_B = df_min}

  
  if (dfBDG_B < 2) {
    print(paste0("DF_BDG is below a minimum.",
                 "DF_BDG was calculated to be ", dfBDG_B, "DF_BDG less than 2 cannot be handled.
                 Therefore, it is being set to 2"))
    dfBDG_B = 2}
  
  
  if (dfBDG_B >= 50) {
    p_BDG_B = p_normal_B
    botCIBDG_B = botCInormal_B
    topCIBDG_B = topCInormal_B
    
  }
  else{
  
  p_BDG_B = (1 - pt(abs(st_normal),df = floor(dfBDG_B)))*2


  botCIBDG_B = (AUC_per_avg_out[[2]]$AvgAUC_est[2]) - qt(0.975,df = floor(dfBDG_B))*sqrt(AUC_per_avg_out[[2]]$Ustat_var[2])


  topCIBDG_B = (AUC_per_avg_out[[2]]$AvgAUC_est[2]) + qt(0.975,df = floor(dfBDG_B))*sqrt(AUC_per_avg_out[[2]]$Ustat_var[2])
  }

  ## create a data frame to store all the output from Ustat

  #Ustat=data.frame(modalities=c(modalities[1],modalities[2],paste0(modalities[1],"-",modalities[2])),Auc_est=c(AUC_per_avg_out[[2]]$AvgAUC_est,AUC_per_avg_out[[2]]$AvgAUC_est[1]-AUC_per_avg_out[[2]]$AvgAUC_est[2]),
  #Var_est=c(AUC_per_avg_out[[2]]$Ustat_var,Ustat_dif_var),pValueNormal=c(p_normal_A,p_normal_B,p_normal_A_B),
  #botCInormal=c(botCInormal_A,botCInormal_B,botCInormal_A_B),topCInormal=c(topCInormal_A,topCInormal_B,topCInormal_A_B),
  #rejectNormal=(c(p_normal_A,p_normal_B,p_normal_A_B)<=0.05),
  #dfBDG=c(dfBDG_A,dfBDG_B,dfBDG_A_B),pValueBDG=c(p_BDG_A,p_BDG_B,p_BDG_A_B),botCIBDG=c(botCIBDG_A,botCIBDG_B,botCIBDG_A_B),
  #topCIBDG=c(topCIBDG_A,topCIBDG_B,topCIBDG_A_B), rejectBDG=(c(p_BDG_A,p_BDG_B,p_BDG_A_B)<=0.05))

  Ustat = data.frame(inputFile = rep("input.imrmc",(nm + 1)) ,
                     date = rep(Sys.Date(),(nm + 1)),
                     MRMC_R_Version = rep("Version 0.0.9", (nm + 1)),
                     NR = rep(nR,(nm + 1)),
                     N0 = rep(nC.neg,(nm + 1)),
                     N1 = rep(nC.pos,(nm + 1)),
                     modalityA = c(modalities,modalities[1]),
                     modalityB = c(rep("NO_MOD",nm),modalities[2]),
                     UstatOrMLE = rep("Ustat",nm + 1),
                     AUCA = c(AUC_per_avg_out[[2]]$AvgAUC_est,AUC_per_avg_out[[2]]$AvgAUC_est[1]),
                     varAUCA = c(AUC_per_avg_out[[2]]$Ustat_var,AUC_per_avg_out[[2]]$Ustat_var[1]),
                     AUCB = c(rep(NA,nm),AUC_per_avg_out[[2]]$AvgAUC_est[2]),
                     varAUCB = c(rep(NA,nm),AUC_per_avg_out[[2]]$Ustat_var[2]),
                     AUCAminusAUCB = c(rep(NA,nm),AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]),
                     varAUCAminusAUCB = c(rep(NA,nm),Ustat_dif_var),
                     pValueNormal = c(p_normal_A,p_normal_B,p_normal_A_B),
                     botCInormal = c(botCInormal_A,botCInormal_B,botCInormal_A_B),
                     topCInormal = c(topCInormal_A,topCInormal_B,topCInormal_A_B),
                     rejectNormal = as.numeric(c(p_normal_A,p_normal_B,p_normal_A_B) <= 0.05),
                     dfBDG = c(dfBDG_A,dfBDG_B,dfBDG_A_B),
                     pValueBDG = c(p_BDG_A,p_BDG_B,p_BDG_A_B),
                     botCIBDG = c(botCIBDG_A,botCIBDG_B,botCIBDG_A_B),
                     topCIBDG = c(topCIBDG_A,topCIBDG_B,topCIBDG_A_B), 
                     rejectBDG = as.numeric(c(p_BDG_A,p_BDG_B,p_BDG_A_B) <= 0.05))

  ################################################################################################################################

  ################################# MLEstat #########################################################################################
  ## MLEstat Variance for AUCA-AUCB
  MLEstat_dif_var = sum(AUC_per_avg_out[[2]]$MLEstat_var) - 2*AUC_cov_out[[3]]

  ## For difference of AUCA-AUCB
  st_normal = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2])/sqrt(MLEstat_dif_var)

  p_normal_A_B = (1 - pnorm(abs(st_normal)))*2



  botCInormal_A_B = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]) - qnorm(0.975)*sqrt(MLEstat_dif_var)


  topCInormal_A_B = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]) + qnorm(0.975)*sqrt(MLEstat_dif_var)


  sbr = (sum(AUC_per_avg_out[[6]][,4]) - 2*AUC_cov_out[[7]][4])^2/(DFreader)^3 #(nR-1)^3
  sb0 = (sum(AUC_per_avg_out[[6]][,1]) - 2*AUC_cov_out[[7]][1])^2/(DFnormal)^3 #(nC.neg-1)^3
  sb1 = (sum(AUC_per_avg_out[[6]][,2]) - 2*AUC_cov_out[[7]][2])^2/(DFdisease)^3 #(nC.pos-1)^3


  # sbr=(sum(AUC_per_avg_out[[6]][,4])-2*AUC_cov_out[[7]][4])^2/(nR-1)^3
  # sb0=(sum(AUC_per_avg_out[[6]][,1])-2*AUC_cov_out[[7]][1])^2/(nC.neg-1)^3
  # sb1=(sum(AUC_per_avg_out[[6]][,2])-2*AUC_cov_out[[7]][2])^2/(nC.pos-1)^3

  dfBDG_A_B = MLEstat_dif_var^2/(sbr + sb1 + sb0)

  df_min = min(DFnormal,DFdisease,DFreader)
  
  if (dfBDG_A_B < df_min) {
    print(paste0("DF_BDG is below a minimum.",
                 "DF_BDG was calculated to be ", dfBDG_A_B, "It is being set to DF_min = ",df_min,
                 "This follows Gaylor1969_Technometrics_v4p691",
                 "and indicates that your data is very limited"))
    dfBDG_A_B = df_min}
  
  
  
  if (dfBDG_A_B < 2) {
    print(paste0("DF_BDG is below a minimum.",
                 "DF_BDG was calculated to be ", dfBDG_A_B, "DF_BDG less than 2 cannot be handled.
                 Therefore, it is being set to 2"))
    dfBDG_A_B = 2}
  
  if (dfBDG_A_B >= 50) {
    p_BDG_A_B = p_normal_A_B
    botCIBDG_A_B = botCInormal_A_B
    topCIBDG_A_B = topCInormal_A_B
    }
  else{

  p_BDG_A_B = (1 - pt(abs(st_normal),df = floor(dfBDG_A_B)))*2


  botCIBDG_A_B = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]) - qt(0.975,df = floor(dfBDG_A_B))*sqrt(MLEstat_dif_var)


  topCIBDG_A_B = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]) + qt(0.975,df = floor(dfBDG_A_B))*sqrt(MLEstat_dif_var)

  }

  ## FOr AUCA


  st_normal = (AUC_per_avg_out[[2]]$AvgAUC_est[1] - 0.5)/sqrt(AUC_per_avg_out[[2]]$MLEstat_var[1])


  p_normal_A = (1 - pnorm(abs(st_normal)))*2



  botCInormal_A = (AUC_per_avg_out[[2]]$AvgAUC_est[1]) - qnorm(0.975)*sqrt(AUC_per_avg_out[[2]]$MLEstat_var[1])


  topCInormal_A = (AUC_per_avg_out[[2]]$AvgAUC_est[1]) + qnorm(0.975)*sqrt(AUC_per_avg_out[[2]]$MLEstat_var[1])


  sbr = (AUC_per_avg_out[[6]][1,4])^2/DFreaderA^3
  sb0 = (AUC_per_avg_out[[6]][1,1])^2/DFnormalA^3
  sb1 = (AUC_per_avg_out[[6]][1,2])^2/DFdiseaseA^3


  dfBDG_A = AUC_per_avg_out[[2]]$MLEstat_var[1]^2/(sbr + sb1 + sb0)
  # sd=0
  # for (i in 1:7){ 
  #
  #   sd=sd+(AUC_per_avg_out[[6]][1,i])^2/(1/BCK_coef[,i])[1]^2/(1/BCK_coef[,i]-1)[1]
  #
  # }
  #
  # dfBDG_A=AUC_per_avg_out[[2]]$MLEstat_var[1]^2/sd

  df_min = min(DFnormalA,DFdiseaseA,DFreaderA)

  if (dfBDG_A < df_min) {
    print(paste0("DF_BDG is below a minimum. ",
                 "DF_BDG was calculated to be ", dfBDG_A, " It is being set to DF_min = ",df_min,
                 " This follows Gaylor1969_Technometrics_v4p691",
                 " and indicates that your data is very limited"))
    dfBDG_A = df_min}
  
  
  
  if (dfBDG_A < 2) {
    print(paste0("DF_BDG is below a minimum. ",
                 "DF_BDG was calculated to be ", dfBDG_A, "DF_BDG less than 2 cannot be handled.
                 Therefore, it is being set to 2"))
    dfBDG_A = 2}
  
  
  
  
  if (dfBDG_A >= 50) {
    p_BDG_A = p_normal_A
    botCIBDG_A = botCInormal_A
    topCIBDG_A = topCInormal_A
  }
  
  else{
    
    p_BDG_A = (1 - pt(abs(st_normal),df = floor(dfBDG_A)))*2
    
    
    botCIBDG_A = (AUC_per_avg_out[[2]]$AvgAUC_est[1]) - qt(0.975,df = floor(dfBDG_A))*sqrt(AUC_per_avg_out[[2]]$MLEstat_var[1])
    
    
    topCIBDG_A = (AUC_per_avg_out[[2]]$AvgAUC_est[1]) + qt(0.975,df = floor(dfBDG_A))*sqrt(AUC_per_avg_out[[2]]$MLEstat_var[1])
    
  }
  
  
  
  
  


  ## For AUCB


  st_normal = (AUC_per_avg_out[[2]]$AvgAUC_est[2] - 0.5)/sqrt(AUC_per_avg_out[[2]]$MLEstat_var[2])


  p_normal_B = (1 - pnorm(abs(st_normal)))*2



  botCInormal_B = (AUC_per_avg_out[[2]]$AvgAUC_est[2]) - qnorm(0.975)*sqrt(AUC_per_avg_out[[2]]$MLEstat_var[2])


  topCInormal_B = (AUC_per_avg_out[[2]]$AvgAUC_est[2]) + qnorm(0.975)*sqrt(AUC_per_avg_out[[2]]$MLEstat_var[2])



  # sbr=(AUC_per_avg_out[[6]][2,4])^2/(1/BCK_coef[,4]-1)[2]^3
  # sb0=(AUC_per_avg_out[[6]][2,1])^2/(1/BCK_coef[,1]-1)[2]^3
  # sb1=(AUC_per_avg_out[[6]][2,2])^2/(1/BCK_coef[,2]-1)[2]^3

  sbr = (AUC_per_avg_out[[6]][2,4])^2/DFreaderB^3
  sb0 = (AUC_per_avg_out[[6]][2,1])^2/DFnormalB^3
  sb1 = (AUC_per_avg_out[[6]][2,2])^2/DFdiseaseB^3

  dfBDG_B = AUC_per_avg_out[[2]]$MLEstat_var[2]^2/(sbr + sb1 + sb0)

#
#   sd=0
#
#   for (i in 1:7){
#
#     sd=sd+(AUC_per_avg_out[[6]][2,i])^2/(1/BCK_coef[,i])[2]^2/(1/BCK_coef[,i]-1)[2]
#   }
#
#   dfBDG_B=AUC_per_avg_out[[2]]$MLEstat_var[2]^2/sd

  df_min = min(DFnormalB,DFdiseaseB,DFreaderB)

  if (dfBDG_B < df_min) {
    print(paste0("DF_BDG is below a minimum. ",
                 "DF_BDG was calculated to be ", dfBDG_B, " It is being set to DF_min = ",df_min,
                 "This follows Gaylor1969_Technometrics_v4p691 ",
                 "and indicates that your data is very limited"))
    dfBDG_B = df_min}
  if (dfBDG_B < 2) {
    print(paste0("DF_BDG is below a minimum. ",
                 "DF_BDG was calculated to be ", dfBDG_B, " DF_BDG less than 2 cannot be handled.
                  Therefore, it is being set to 2"))
    dfBDG_B = 2}
  
  if (dfBDG_B >= 50) {
    p_BDG_B = p_normal_B
    botCIBDG_B = botCInormal_B
    topCIBDG_B = topCInormal_B
  }
  
  else{
  
  p_BDG_B = (1 - pt(abs(st_normal),df = floor(dfBDG_B)))*2


  botCIBDG_B = (AUC_per_avg_out[[2]]$AvgAUC_est[2]) - qt(0.975,df = floor(dfBDG_B))*sqrt(AUC_per_avg_out[[2]]$MLEstat_var[2])


  topCIBDG_B = (AUC_per_avg_out[[2]]$AvgAUC_est[2]) + qt(0.975,df = floor(dfBDG_B))*sqrt(AUC_per_avg_out[[2]]$MLEstat_var[2])
  }

  ## create a data frame to store all the output from MLEstat

  #MLEstat=data.frame(modalities=c(modalities[1],modalities[2],paste0(modalities[1],"-",modalities[2])),Auc_est=c(AUC_per_avg_out[[2]]$AvgAUC_est,AUC_per_avg_out[[2]]$AvgAUC_est[1]-AUC_per_avg_out[[2]]$AvgAUC_est[2]),
  #Var_est=c(AUC_per_avg_out[[2]]$MLEstat_var,MLEstat_dif_var),pValueNormal=c(p_normal_A,p_normal_B,p_normal_A_B),
  #botCInormal=c(botCInormal_A,botCInormal_B,botCInormal_A_B),topCInormal=c(topCInormal_A,topCInormal_B,topCInormal_A_B),
  # rejectNormal=(c(p_normal_A,p_normal_B,p_normal_A_B)<=0.05),
  #dfBDG=c(dfBDG_A,dfBDG_B,dfBDG_A_B),pValueBDG=c(p_BDG_A,p_BDG_B,p_BDG_A_B),botCIBDG=c(botCIBDG_A,botCIBDG_B,botCIBDG_A_B),
  #topCIBDG=c(topCIBDG_A,topCIBDG_B,topCIBDG_A_B), rejectBDG=(c(p_BDG_A,p_BDG_B,p_BDG_A_B)<=0.05))

  MLEstat = data.frame(
    inputFile = rep("input.imrmc",(nm + 1)) ,
    date = rep(Sys.Date(),(nm + 1)),
    MRMC_R_Version = rep("Version 0.0.9", (nm + 1)),
    NR = rep(nR,(nm + 1)),
    N0 = rep(nC.neg,(nm + 1)),
    N1 = rep(nC.pos,(nm + 1)),
    modalityA = c(modalities,modalities[1]),
    modalityB = c(rep("NO_MOD",nm),modalities[2]),
    UstatOrMLE = rep("MLE",nm + 1),
    AUCA = c(AUC_per_avg_out[[2]]$AvgAUC_est,AUC_per_avg_out[[2]]$AvgAUC_est[1]),
    varAUCA = c(AUC_per_avg_out[[2]]$MLEstat_var,AUC_per_avg_out[[2]]$MLEstat_var[1]),
    AUCB = c(rep(NA,nm),AUC_per_avg_out[[2]]$AvgAUC_est[2]),
    varAUCB = c(rep(NA,nm),AUC_per_avg_out[[2]]$MLEstat_var[2]),
    AUCAminusAUCB = c(rep(NA,nm),AUC_per_avg_out[[2]]$AvgAUC_est[1] - AUC_per_avg_out[[2]]$AvgAUC_est[2]),
    varAUCAminusAUCB = c(rep(NA,nm),MLEstat_dif_var),
    pValueNormal = c(p_normal_A,p_normal_B,p_normal_A_B),
    botCInormal = c(botCInormal_A,botCInormal_B,botCInormal_A_B),
    topCInormal = c(topCInormal_A,topCInormal_B,topCInormal_A_B),
    rejectNormal = as.numeric(c(p_normal_A,p_normal_B,p_normal_A_B) <= 0.05),
    dfBDG = c(dfBDG_A,dfBDG_B,dfBDG_A_B),
    pValueBDG = c(p_BDG_A,p_BDG_B,p_BDG_A_B),
    botCIBDG = c(botCIBDG_A,botCIBDG_B,botCIBDG_A_B),
    topCIBDG = c(topCIBDG_A,topCIBDG_B,topCIBDG_A_B),
    rejectBDG = as.numeric(c(p_BDG_A,p_BDG_B,p_BDG_A_B) <= 0.05)
  )

  #########################################################################################################################################################################

  ######### Var comp#########################


  ####### BCK ######################################

  ## Ustat #############################
  d1 = matrix(0,nrow = 3,ncol = 7)
  d1[1,] = AUC_per_avg_out[[5]][1,]
  d1 = as.data.frame(d1)
  colnames(d1) = c("N","D","ND","R","NR","DR","RND")
  rownames(d1) = c(modalities[1],"NO_MOD",paste0(modalities[1],".NO_MOD"))
  names_d1 = paste0(modalities[1],".NO_MOD")


  d2 = matrix(0,nrow = 3,ncol = 7)
  d2[1,] = AUC_per_avg_out[[5]][2,]
  d2 = as.data.frame(d2)
  colnames(d2) = c("N","D","ND","R","NR","DR","RND")
  rownames(d2) = c(modalities[2],"NO_MOD",paste0(modalities[2],".NO_MOD"))
  names_d2 = paste0(modalities[2],".NO_MOD")


  d3 = matrix(0,nrow = 3,ncol = 7)
  d3[1,] = AUC_per_avg_out[[5]][1,]
  d3[2,] = AUC_per_avg_out[[5]][2,]
  d3[3,] = AUC_cov_out[[6]]
  d3 = as.data.frame(d3)
  colnames(d3) = c("N","D","ND","R","NR","DR","RND")
  rownames(d3) = c(modalities[1],modalities[2],paste0(modalities[1],".",modalities[2]))
  names_d3 = paste0(modalities[1],".",modalities[2])

  Ustat_BCK_comp = list(d1,d2,d3)
  names(Ustat_BCK_comp) = c(names_d1,names_d2,names_d3)





  d1 = matrix(0,nrow = 3,ncol = 7)
  d1[1,] = BCK_coef[1,]
  d1 = as.data.frame(d1)
  colnames(d1) = c("N","D","ND","R","NR","DR","RND")
  rownames(d1) = c(modalities[1],"NO_MOD",paste0(modalities[1],".NO_MOD"))
  #names(d1)=paste0(modalities[1],".NO_MOD")


  d2 = matrix(0,nrow = 3,ncol = 7)
  d2[1,] = BCK_coef[2,]
  d2 = as.data.frame(d2)
  colnames(d2) = c("N","D","ND","R","NR","DR","RND")
  rownames(d2) = c(modalities[2],"NO_MOD",paste0(modalities[2],".NO_MOD"))
  #names(d2)=paste0(modalities[2],".NO_MOD")


  d3 = matrix(0,nrow = 3,ncol = 7)
  d3[1,] = BCK_coef[1,]
  d3[2,] = BCK_coef[2,]
  d3[3,] = 2*BCK_cov_coef
  d3 = as.data.frame(d3)
  colnames(d3) = c("N","D","ND","R","NR","DR","RND")
  rownames(d3) = c(modalities[1],modalities[2],paste0(modalities[1],".",modalities[2]))
  #names(d3)=paste0(modalities[1],".",modalities[2])

  Ustat_BCK_coeff = list(d1,d2,d3)
  names(Ustat_BCK_coeff) = c(names_d1,names_d2,names_d3)

  #### MLE ############

  d1 = matrix(0,nrow = 3,ncol = 7)
  d1[1,] = AUC_per_avg_out[[6]][1,]
  d1 = as.data.frame(d1)
  colnames(d1) = c("N","D","ND","R","NR","DR","RND")
  rownames(d1) = c(modalities[1],"NO_MOD",paste0(modalities[1],".NO_MOD"))
  #names(d1)=paste0(modalities[1],".NO_MOD")


  d2 = matrix(0,nrow = 3,ncol = 7)
  d2[1,] = AUC_per_avg_out[[6]][2,]
  d2 = as.data.frame(d2)
  colnames(d2) = c("N","D","ND","R","NR","DR","RND")
  rownames(d2) = c(modalities[2],"NO_MOD",paste0(modalities[2],".NO_MOD"))
  #names(d2)=paste0(modalities[2],".NO_MOD")


  d3 = matrix(0,nrow = 3,ncol = 7)

  d3[1,] = AUC_per_avg_out[[6]][1,]
  d3[2,] = AUC_per_avg_out[[6]][2,]
  d3[3,] = AUC_cov_out[[7]]
  d3 = as.data.frame(d3)
  colnames(d3) = c("N","D","ND","R","NR","DR","RND")
  rownames(d3) = c(modalities[1],modalities[2],paste0(modalities[1],".",modalities[2]))
  #names(d3)=paste0(modalities[1],".",modalities[2])

  MLE_BCK_comp = list(d1,d2,d3)

  names(MLE_BCK_comp) = c(names_d1,names_d2,names_d3)
  MLE_BCK_coeff = Ustat_BCK_coeff


  MLE_BCK = list(comp = MLE_BCK_comp,coeff = MLE_BCK_coeff)
  Ustat_BCK = list(comp = Ustat_BCK_comp,coeff = Ustat_BCK_coeff)
  BCK = list(MLE = MLE_BCK,Ustat = Ustat_BCK)


  ####### BDG #####################################




  ## Ustat ############

  d1 = matrix(0,nrow = 3,ncol = 8)
  d1[1,] = AUC_per_avg_out[[3]][1,]
  d1 = as.data.frame(d1)
  colnames(d1) = paste0("M",1:8)
  rownames(d1) = c(modalities[1],"NO_MOD",paste0(modalities[1],".NO_MOD"))
  #names(d1)=paste0(modalities[1],".NO_MOD")


  d2 = matrix(0,nrow = 3,ncol = 8)
  d2[1,] = AUC_per_avg_out[[3]][2,]
  d2 = as.data.frame(d2)
  colnames(d2) = paste0("M",1:8)
  rownames(d2) = c(modalities[2],"NO_MOD",paste0(modalities[2],".NO_MOD"))
  #names(d2)=paste0(modalities[2],".NO_MOD")


  d3 = matrix(0,nrow = 3,ncol = 8)
  d3[1,] = AUC_per_avg_out[[3]][1,]
  d3[2,] = AUC_per_avg_out[[3]][2,]
  d3[3,] = AUC_cov_out[[4]]
  d3 = as.data.frame(d3)
  colnames(d3) = paste0("M",1:8)
  rownames(d3) = c(modalities[1],modalities[2],paste0(modalities[1],".",modalities[2]))
  #names(d3)=paste0(modalities[1],".",modalities[2])

  Ustat_BDG_comp = list(d1,d2,d3)

  names(Ustat_BDG_comp) = c(names_d1,names_d2,names_d3)

  # c1=1/(nC.pos*nC.neg)
  # c2=(nC.neg-1)/(nC.neg*nC.pos)
  # c3=(nC.pos-1)/(nC.neg*nC.pos)
  # c4=(nC.pos-1)*(nC.neg-1)/(nC.neg*nC.pos)
  # BDG_coeff=c(1/nR*c(c1,c2,c3,c4),(nR-1)/nR*c(c1,c2,c3),(nR-1)/nR*c4-1)
  d1 = matrix(0,nrow = 3,ncol = 8)
  d1[1,] = BDG_coef[1,]
  d1 = as.data.frame(d1)
  colnames(d1) = paste0("M",1:8)
  rownames(d1) = c(modalities[1],"NO_MOD",paste0(modalities[1],".NO_MOD"))
  #names(d1)=paste0(modalities[1],".NO_MOD")


  d2 = matrix(0,nrow = 3,ncol = 8)
  d2[1,] = BDG_coef[2,]
  d2 = as.data.frame(d2)
  colnames(d2) = paste0("M",1:8)
  rownames(d2) = c(modalities[2],"NO_MOD",paste0(modalities[2],".NO_MOD"))
  #names(d2)=paste0(modalities[2],".NO_MOD")


  d3 = matrix(0,nrow = 3,ncol = 8)
  d3[1,] = BDG_coef[1,]
  d3[2,] = BDG_coef[2,]
  d3[3,] = 2*BDG_cov_coef
  d3 = as.data.frame(d3)
  colnames(d3) = paste0("M",1:8)
  rownames(d3) = c(modalities[1],modalities[2],paste0(modalities[1],".",modalities[2]))
  #names(d3)=paste0(modalities[1],".",modalities[2])

  Ustat_BDG_coeff = list(d1,d2,d3)

  names(Ustat_BDG_coeff) = c(names_d1,names_d2,names_d3)


  ## MLE ############

  d1 = matrix(0,nrow = 3,ncol = 8)
  d1[1,] = AUC_per_avg_out[[4]][1,]
  d1 = as.data.frame(d1)
  colnames(d1) = paste0("M",1:8)
  rownames(d1) = c(modalities[1],"NO_MOD",paste0(modalities[1],".NO_MOD"))
  #names(d1)=paste0(modalities[1],".NO_MOD")


  d2 = matrix(0,nrow = 3,ncol = 8)
  d2[1,] = AUC_per_avg_out[[4]][2,]
  d2 = as.data.frame(d2)
  colnames(d2) = paste0("M",1:8)
  rownames(d2) = c(modalities[2],"NO_MOD",paste0(modalities[2],".NO_MOD"))
  #names(d2)=paste0(modalities[2],".NO_MOD")


  d3 = matrix(0,nrow = 3,ncol = 8)
  d3[1,] = AUC_per_avg_out[[4]][1,]
  d3[2,] = AUC_per_avg_out[[4]][2,]
  d3[3,] = AUC_cov_out[[5]]
  d3 = as.data.frame(d3)
  colnames(d3) = paste0("M",1:8)
  rownames(d3) = c(modalities[1],modalities[2],paste0(modalities[1],".",modalities[2]))
  #names(d3)=paste0(modalities[1],".",modalities[2])

  MLE_BDG_comp = list(d1,d2,d3)
  names(MLE_BDG_comp) = c(names_d1,names_d2,names_d3)

  MLE_BDG_coeff = Ustat_BDG_coeff


  MLE_BDG = list(comp = MLE_BDG_comp,coeff = MLE_BDG_coeff)
  Ustat_BDG = list(comp = Ustat_BDG_comp,coeff = Ustat_BDG_coeff)
  BDG = list(MLE = MLE_BDG,Ustat = Ustat_BDG)

  varDecomp = list(BCK = BCK,BDG = BDG)

  #########################################################################################################################################################################
  
  
  ########################## ROC ########################################################################################################################
  
  
  #### per reader ROC #######
  #true_ID=(data %>% filter(modalityID=="truth"))$score
  ## function for calculating roc points
  roc_points = function(thres,score,trueID){
    num_neg = length(trueID[trueID == 0])
    num_pos = length(trueID[trueID == 1])
    temp_df = data.frame(s = score,t = trueID)
    
    tpf = dim(temp_df[(temp_df$s > thres & temp_df$t == 1),])[1]/num_pos
    fpf = dim(temp_df[(temp_df$s > thres & temp_df$t == 0),])[1]/num_neg
    #tpf = (temp_df %>% filter(s > thres & t == 1) %>% dim())[1]/num_pos
    #fpf = (temp_df %>% filter(s > thres & t == 0) %>% dim())[1]/num_neg
    return(c(tpf,fpf))
  }
  ROC = vector("list",(nR + 4)*nm)
  
  ROC_perReader = vector("list",nR*nm)
  
  for (m in 1:nm) {
    
    #mod=data %>% filter(modalityID==modalities[m])
    
    mod = data[data$modalityID == modalities[m], ]
    min_s = min(mod$score)
    max_s = max(mod$score)
    #inc=(max_s-min_s)/(nC.neg+nC.pos)
    inc = (max_s - min_s)/100
    threshold = seq(max_s + inc,min_s - inc,by = -inc)
    for (i in 1:nR) {
      
      
      true_ID = c(rep(0,s_m[[3]][m,1,i]),rep(1,s_m[[3]][m,2,i]))
      #r_score = (mod %>% filter(readerID==readers[i]))$score
      r_score = mod[mod$readerID == readers[i], ]$score
      
      #temp_tf = sapply(threshold,roc_points,score = r_score,trueID = true_ID) %>% t() %>% as.data.frame() %>% distinct()
      temp_tf = as.data.frame(t(sapply(threshold,roc_points,score = r_score,trueID = true_ID)))
      temp_tf = unique(temp_tf)
      
      ROC_perReader[[(m - 1)*nR + i]] = temp_tf
      #ROC[[(m-1)*(nR+4)+3+i]]=sapply(threshold,roc_points,score=r_score,trueID=true_ID) %>% t() %>% as.data.frame() %>% distinct()
      ROC[[(m - 1)*(nR + 4) + 3 + i]] = list(desc = paste0(modalities[m],": ",readers[i]), n = dim(temp_tf)[1], fpf = temp_tf[,2], tpf = temp_tf[,1])
      names(ROC)[(m - 1)*(nR + 4) + 3 + i] = paste0(modalities[m],": ",readers[i])
    }
  }
  
  
  #### pooled ROC #######
  pool_roc_points = function(thres,score,trueID){
    num_neg = length(trueID[trueID == 0])
    num_pos = length(trueID[trueID == 1])
    temp_df = data.frame(s = score,t = trueID)
    #tpf = (temp_df %>% filter(s>thres & t==1) %>% dim())[1]/num_pos
    #fpf = (temp_df %>% filter(s>thres & t==0) %>% dim())[1]/num_neg
    tpf = dim(temp_df[(temp_df$s > thres & temp_df$t == 1),])[1]/num_pos
    fpf = dim(temp_df[(temp_df$s > thres & temp_df$t == 0),])[1]/num_neg
    return(c(tpf,fpf))
  }
  for (m in 1:nm) {
    
    #mod=data %>% filter(modalityID==modalities[m])
    mod = data[data$modalityID == modalities[m], ]
    min_s = min(mod$score)
    max_s = max(mod$score)
    #inc=(max_s-min_s)/(nC.neg+nC.pos)
    inc = (max_s - min_s)/100
    threshold = seq(max_s + inc,min_s - inc,by = -inc)
    #browser()
    true_ID = rep(rep(c(0,1),each = nR),t(s_m[[3]][m,,]))
    temp_tf = as.data.frame(t(sapply(threshold,pool_roc_points,score = mod$score,trueID = true_ID)))
    temp_tf = unique(temp_tf)
    ROC[[(m - 1)*(nR + 4) + 3]] = list(desc = paste0(modalities[m],": ","Pooled Average"), n = dim(temp_tf)[1], fpf = temp_tf[,2], tpf = temp_tf[,1])
    names(ROC)[(m - 1)*(nR + 4) + 3] = paste0(modalities[m],": ","Pooled Average")
    
  }
  
  
  ### Vertical average ROC #########
  
  ## step 1 for each reader average over x
  avg_each_xpoint = function(points,data){
    
    
    #if (sum(data[,2]==points)==1){return(c(mean(data[data[,2]==points,][1]),points))}
    #else{
    return(c(mean(data[data[,2] == points,][,1]),points))
  }
  
  avg_reader_roc = function(readers_roc,ax=2){
    
    unique_points = sort(unique(readers_roc[,ax]))
    
    return(t(sapply(unique_points,avg_each_xpoint,data = readers_roc)))
    
  }
  
  
  
  ## step 2 interpolate calculation given each reader x axis averaged roc
  
  
  interpolate_points_x = function(x,per_roc){
    
    
    if (x > 1) {y = 1}
    else if (x >= max(per_roc[,2])) {y = per_roc[which.max(per_roc[,2]),1]}
    else if (x <= 0) {y = 0}
    else{
      temp_i = rank(c(x,per_roc[,2]),ties.method = "first")[1]
      #print(temp_i)
      
      
      two_points = per_roc[(temp_i - 1):temp_i,]
      #print(temp_i)
      
      m = (two_points[2,1] - two_points[1,1])/(two_points[2,2] - two_points[1,2])
      b = two_points[1,1] - two_points[1,2]*m
      y = m*x + b
    }
    return(y)
    
    
  }
  
  cut_points = seq(0,1,by = 0.01)
  #readers_roc_A=list(r1_A_roc,r2_A_roc,r3_A_roc,r4_A_roc,r5_A_roc)
  #readers_roc_B=list(r1_B_roc,r2_B_roc,r3_B_roc,r4_B_roc,r5_B_roc)
  #avg_reader_A=list()
  #readers=paste0("r",1:5)
  temp_y_A = matrix(0,nrow = length(cut_points),ncol = nR)
  temp_y_B = matrix(0,nrow = length(cut_points),ncol = nR)
  for (i in 1:nR) {
    
    temp_y_A[,i] = sapply(cut_points,interpolate_points_x,per_roc = avg_reader_roc(ROC_perReader[[i]],ax = 2))
    temp_y_B[,i] = sapply(cut_points,interpolate_points_x,per_roc = avg_reader_roc(ROC_perReader[[i + nR]],ax = 2))
    
  }
  
  
  ROC[[nR + 4]] = list(desc = paste0(modalities[1],": ","Vertical Average"), 
                     n = length(cut_points), 
                     fpf = cut_points, 
                     tpf = apply(temp_y_A,MARGIN = 1,FUN = mean))
  names(ROC)[nR + 4] = paste0(modalities[1],": ","Vertical Average")
  ROC[[2*(nR + 4)]] = list(desc = paste0(modalities[2],": ","Vertical Average"), 
                           n = length(cut_points), 
                           fpf = cut_points, 
                           tpf = apply(temp_y_B,MARGIN = 1,FUN = mean))
  names(ROC)[2*(nR + 4)] = paste0(modalities[2],": ","Vertical Average")
  
  ##### horizontal average ROC #######
  
  ## step1 same as vertical
  
  
  ## step 2 interpolate calculation given each reader x axis averaged roc
  
  
  interpolate_points_y = function(y,per_roc){
    
    
    if (y >= 1) {x = 1}
    #else if(y>=max(per_roc[,1])){x=per_roc[which.max(per_roc[,1]),2]}
    else if (y <= 0) {x = 0}
    else{
      temp_i = rank(c(y,per_roc[,1]),ties.method = "first")[1]
      #print(temp_i)
      
      if (temp_i == 1) {x = per_roc[1,2]}
      else if (temp_i == dim(per_roc)[1] + 1) {
        x = per_roc[,2][length(per_roc[,2])] #{x = last(per_roc[,2])}
      }
        
      else{
        two_points = per_roc[(temp_i - 1):temp_i,]
        #print(temp_i)
        
        m = (two_points[2,1] - two_points[1,1])/(two_points[2,2] - two_points[1,2])
        b = two_points[1,1] - two_points[1,2]*m
        x = (y - b)/m}
    }
    
    return(x)
  }
  
  
  #avg_reader_A=list()
  #readers=paste0("r",1:5)
  
  temp_x_A = matrix(0,nrow = length(cut_points),ncol = nR)
  temp_x_B = matrix(0,nrow = length(cut_points),ncol = nR)
  
  
  for (i in 1:nR) {
    
    temp_x_A[,i] = sapply(cut_points,interpolate_points_y,per_roc = avg_reader_roc(ROC_perReader[[i]],ax = 2))
    temp_x_B[,i] = sapply(cut_points,interpolate_points_y,per_roc = avg_reader_roc(ROC_perReader[[i + nR]],ax = 2))
    
  }
  
  
  ROC[[2]] = list(desc = paste0(modalities[1],": ","Horizontal Average"), 
                n = length(cut_points), 
                fpf = apply(temp_x_A,MARGIN = 1,FUN = mean), 
                tpf = cut_points)
  names(ROC)[2] = paste0(modalities[1],": ","Horizontal Average")
  ROC[[(nR + 6)]] = list(desc = paste0(modalities[2],": ","Horizontal Average"), 
                         n = length(cut_points), 
                         fpf = apply(temp_x_B,MARGIN = 1,FUN = mean), 
                         tpf = cut_points)
  names(ROC)[nR + 6] = paste0(modalities[2],": ","Horizontal Average")
  
  ##### diagonally averaged ROC #########
  
  
  
  ## step 1 rotate all points 45 degrees clockwise about origin
  
  rotate45 = function(roc_per_reader){
    
    x2 = apply(roc_per_reader,MARGIN = 1,sum)/sqrt(2)
    y2 = (roc_per_reader[,1] - roc_per_reader[,2])/sqrt(2)
    return(cbind(y2,x2))
    
  }
  rotate_roc_A = sapply(ROC_perReader[1:nR], rotate45)
  rotate_roc_B = sapply(ROC_perReader[(nR + 1):(2*nR)], rotate45)
  cut_points_diag = seq(0,sqrt(2),by = 0.01)
  
  interpolate_points_diag = function(y,rotate_roc){
    
    if (y >= sqrt(2)) {x = 0}
    #else if(d>=max(per_roc[,1])){x=per_roc[which.max(per_roc[,1]),2]}
    else if (y <= 0) {x = 0}
    else{
      temp_i = rank(c(y,rotate_roc[,2]),ties.method = "first")[1]
      #print(temp_i)
      
      if (temp_i == 1) {x = rotate_roc[1,1]}
      else{
        two_points = rotate_roc[(temp_i - 1):temp_i,]
        #print(temp_i)
        
        m = (two_points[2,1] - two_points[1,1])/(two_points[2,2] - two_points[1,2])
        b = two_points[1,1] - two_points[1,2]*m
        x = m*y + b}
    }
    
    return(x)
    
  }
  avg_each_xpoint_diag = function(points,data){
    
    
    if (sum(data[,2] == points) == 1) {return(c(mean(data[data[,2] == points,][1]),points))}
    else{
      return(c(mean(data[data[,2] == points,][,1]),points))}
  }
  
  avg_reader_roc_diag = function(readers_roc,ax = 2){
    
    unique_points = sort(unique(readers_roc[,ax]))
    
    return(t(sapply(unique_points,avg_each_xpoint_diag,data = readers_roc)))
    
  }
  
  
  temp_y_A_diag = matrix(0,nrow = length(cut_points_diag),ncol = nR)
  temp_y_B_diag = matrix(0,nrow = length(cut_points_diag),ncol = nR)
  for (i in 1:nR) {
    
    temp_y_A_diag[,i] = sapply(cut_points_diag,interpolate_points_diag,rotate_roc = avg_reader_roc_diag(rotate_roc_A[[i]],ax = 2))
    temp_y_B_diag[,i] = sapply(cut_points_diag,interpolate_points_diag,rotate_roc = avg_reader_roc_diag(rotate_roc_B[[i]],ax = 2))
    
  }
  
  avg_y_diag_A = apply(temp_y_A_diag,MARGIN = 1,FUN = mean)
  avg_y_diag_B = apply(temp_y_B_diag,MARGIN = 1,FUN = mean)
  
  ## rotate back
  
  rb_x_A = c(cut_points_diag*cos(pi/4) - avg_y_diag_A*sin(pi/4),1)
  rb_y_A = c(cut_points_diag*sin(pi/4) + avg_y_diag_A*cos(pi/4),1)
  
  rb_x_B = c(cut_points_diag*cos(pi/4) - avg_y_diag_B*sin(pi/4),1)
  rb_y_B = c(cut_points_diag*sin(pi/4) + avg_y_diag_B*cos(pi/4),1)
  
  ROC[[1]] = list(desc = paste0(modalities[1],": ","Diagonal Average"), 
                  n = length(rb_y_A), 
                  fpf = rb_x_A, 
                  tpf = rb_y_A)
  names(ROC)[1] = paste0(modalities[1],": ","Diagonal Average")
  ROC[[(nR + 5)]] = list(desc = paste0(modalities[2],": ","Diagonal Average"), 
                         n = length(rb_x_B), 
                         fpf = rb_x_B, 
                         tpf = rb_y_B)
  names(ROC)[nR + 5] = paste0(modalities[2],": ","Diagonal Average")
  
  return(list(perReader = perReader,Ustat = Ustat,MLEstat = MLEstat,varDecomp = varDecomp,ROC = ROC))

}





## Generate success matrix for all readers and all modalities

success_matrix_arbitrary = function(data){
  
  ## create the truth data frame 
  truthDF = data[data$modalityID == "truth",]

  nR = length(levels(data$readerID)) - 1
  #nC.neg = (data %>% filter(modalityID == 'truth'& score==0) %>% dim())[1]
  #nC.pos = (data %>% filter(modalityID == 'truth'& score==1) %>% dim())[1]
  
  truth.neg = data[(data$modalityID == 'truth' & data$score == 0), ] 
  nC.neg = nrow(truth.neg)
  
  truth.pos = data[(data$modalityID == 'truth' & data$score == 1), ] 
  nC.pos = nrow(truth.pos)
  
  nm = length(levels(data$modalityID)) - 1
  output = array(0,dim = c(nm,nC.neg,nC.pos,nR))
  counts = array(0,dim = c(nm,nC.neg,nC.pos,nR))

  cross_pos = array(0,dim = c(2,nC.pos,nR))
  cross_neg = array(0,dim = c(2,nC.neg,nR))
  cross_count = list(cross_pos,cross_neg)
  total_count = array(0,dim = c(nm,2,nR))
  modalities = levels(data$modalityID)[-1]
  readers = levels(data$readerID)[-1]

  for (m in 1:nm) {

    for (r in 1:nR) {
      #temp_data = data %>% filter(readerID==readers[r] & modalityID==modalities[m])
      
      
      temp_data = data[(data$readerID == readers[r] & data$modalityID == modalities[m]), ]
      
      #browser()
      
      ## find the available data for positive/negative ROI
      
      nC.pos_index = which(truthDF[truthDF$score == 1,]$caseID %in% temp_data$caseID) 
      nC.neg_index = which(truthDF[truthDF$score == 0,]$caseID %in% temp_data$caseID)
      
      
      #nC.neg_avail = grep("neg",temp_data$caseID)
      #nC.pos_avail = grep("pos",temp_data$caseID)
      
      nC.neg_avail = which(temp_data$caseID %in% truthDF[truthDF$score == 0,]$caseID)
      nC.pos_avail = which(temp_data$caseID %in% truthDF[truthDF$score == 1,]$caseID)
      
      #negID = temp_data$caseID[nC.neg_avail]
      #posID = temp_data$caseID[nC.pos_avail]
      
      ## get the available ROIs' length and store
      l_neg_avail = length(nC.neg_avail)
      l_pos_avail = length(nC.pos_avail)
      total_count[m,1,r] = l_neg_avail
      total_count[m,2,r] = l_pos_avail
      
      
      ## create the binary vector indating available
      temp_count_neg = rep(0,nC.neg)
      temp_count_pos = rep(0,nC.pos)
      
      temp_count_neg[nC.neg_index] = 1

      temp_count_pos[nC.pos_index] = 1

      ## create the indicator matrix of available ROIs
      
      cross_count[[1]][m,,r] = temp_count_pos
      cross_count[[2]][m,,r] = temp_count_neg
      
      temp_m1 = matrix(temp_count_neg,nrow = nC.pos,ncol = nC.neg,byrow = T)
      temp_m2 = matrix(temp_count_pos,nrow = nC.pos,ncol = nC.neg,byrow = F)
      counts[m,,,r] = t(temp_m1*temp_m2)
      
      
      
      ## create the score matrix 
      temp_score_neg = rep(0,nC.neg)
      temp_score_pos = rep(0,nC.pos)



      #temp_score_neg=temp_data$score[nC.neg_avail]#,rep(0,nC.neg-l_neg_avail))
      #temp_score_pos=temp_data$score[nC.pos_avail]#,rep(0,nC.pos-l_pos_avail))

     
      #temp_score_neg[as.numeric(gsub("negCase","", negID))] = temp_data$score[nC.neg_avail]
      #temp_score_pos[as.numeric(gsub("posCase","", posID))] = temp_data$score[nC.pos_avail]
      
      temp_score_neg[nC.neg_index] = temp_data$score[nC.neg_avail]
      temp_score_pos[nC.pos_index] = temp_data$score[nC.pos_avail]

      temp_m11 = matrix(temp_score_neg,nrow = nC.pos,ncol = nC.neg,byrow = T)
      temp_m21 = matrix(temp_score_pos,nrow = nC.pos,ncol = nC.neg,byrow = F)
      temp_dif = temp_m21 - temp_m11
      temp_dif[temp_dif > 0] = 1
      temp_dif[temp_dif == 0] = 0.5
      temp_dif[temp_dif < 0] = 0


      output[m,,,r] = t(temp_dif*temp_m1*temp_m2)


    }
  }

  cross_out = rbind(apply(cross_count[[1]],3,cross_c),apply(cross_count[[2]],3,cross_c))
  return(list(output,counts,total_count,cross_out))
}



## function for calculating cross counts

cross_c = function(data){

  return(sum(data[1,] == data[2,]) - sum(which(data[1,] == data[2,]) %in% which(data[1,] == 0)))

}

## function for calculating building block of moments estimate
per_square = function(x){

  return(sum((as.vector(x)) %*% t(as.vector(x))))

}


## Return the per-reader/reader-average AUC and variance



AUC_varAUC_arbitrary = function(data,s_output){

  ## beta matrix--transfer BDG to BCK
  B_alpha = matrix(c(0,0,0,0,0,0,1,-1,
                   0,0,0,0,0,1,0,-1,
                   0,0,0,0,1,-1,-1,1,
                   0,0,0,1,0,0,0,-1,
                   0,0,1,-1,0,0,-1,1,
                   0,1,0,-1,0,-1,0,1,
                   1,-1,-1,1,-1,1,1,-1),nrow = 7,ncol = 8,byrow = T)
  modalities = levels(data$modalityID)[-1]
  readers = levels(data$readerID)[-1]

  s_matrix = s_output[[1]]
  count_matrix = s_output[[2]]
  nm = dim(s_matrix)[1]
  nR = dim(s_matrix)[4]
  nC.neg = dim(s_matrix)[3]
  nC.pos = dim(s_matrix)[2]

  #c1=1/(nC.pos*nC.neg)
  #c2=(nC.neg-1)/(nC.neg*nC.pos)
  #c3=(nC.pos-1)/(nC.neg*nC.pos)
  #c4=(nC.pos-1)*(nC.neg-1)/(nC.neg*nC.pos)

  AUC_out = apply(s_matrix,c(1,4),sum)/apply(count_matrix,c(1,4),sum)

  Ustat_8m = matrix(0,nrow = nm,ncol = 8)
  MLEstat_8m = matrix(0,nrow = nm,ncol = 8)

  b1 = apply((s_matrix)^2,c(1,4),sum)
  c1 = apply((count_matrix)^2,c(1,4),sum)
  #b2 = apply(s_matrix,c(1,3,4),per_square) %>% apply(c(1,3),sum)
  b2 = apply(apply(s_matrix,c(1,3,4),per_square), c(1,3),sum)
  #c2 = apply(count_matrix,c(1,3,4),per_square) %>% apply(c(1,3),sum)
  c2 = apply(apply(count_matrix,c(1,3,4),per_square), c(1,3),sum)
  #b3 = apply(s_matrix,c(1,2,4),per_square) %>% apply(c(1,3),sum)
  b3 = apply(apply(s_matrix,c(1,2,4),per_square), c(1,3),sum)
  #c3 = apply(count_matrix,c(1,2,4),per_square) %>% apply(c(1,3),sum)
  c3 = apply(apply(count_matrix,c(1,2,4),per_square), c(1,3),sum)
  b4 = apply(s_matrix,c(1,4),per_square)
  c4 = apply(count_matrix,c(1,4),per_square)


  M1 = b1/c1
  M2 = (b2 - b1)/(c2 - c1)
  M3 = (b3 - b1)/(c3 - c1)
  M4 = (b4 - b2 - b3 + b1)/(c4 - c2 - c3 + c1)

  ## variance AUC for each reader
  #varAUC_pereader=c1*M1+c2*M2+c3*M3+(c4-1)*M4
  varAUC_pereader = (M1*c1 + M2*(c2 - c1) + M3*(c3 - c1) + M4*(c4 - c2 - c3 + c1))/(c1^2) - M4
  out1 = data.frame(modality = rep(modalities,each = nR),
                    reader = rep(readers,nm),
                    AUC_est = as.vector(t(AUC_out)),
                    varAUC = as.vector(t(varAUC_pereader)))


  ## buliding block for moments estimate

  blk1 = apply((s_matrix)^2,1,sum)
  blk1_c = apply((count_matrix)^2,1,sum)
  MLEstat_8m[,1] = blk1/blk1_c
  #blk2 = apply(s_matrix,c(1,3,4),per_square) %>% apply(1,sum)
  blk2 = apply(apply(s_matrix,c(1,3,4),per_square),1,sum) 
  #blk2_c = apply(count_matrix,c(1,3,4),per_square) %>% apply(1,sum)
  blk2_c = apply(apply(count_matrix,c(1,3,4),per_square),1,sum)
  MLEstat_8m[,2] = blk2/blk2_c
  #blk3 = apply(s_matrix,c(1,2,4),per_square) %>% apply(1,sum)
  blk3 = apply(apply(s_matrix,c(1,2,4),per_square),1,sum)
  #blk3_c = apply(count_matrix,c(1,2,4),per_square) %>% apply(1,sum)
  blk3_c = apply(apply(count_matrix,c(1,2,4),per_square), 1,sum)
  MLEstat_8m[,3] = blk3/blk3_c
  #blk4 = apply(s_matrix,c(1,4),per_square) %>% apply(1,sum)
  blk4 = apply(apply(s_matrix,c(1,4),per_square),1,sum)
  #blk4_c = apply(count_matrix,c(1,4),per_square) %>% apply(1,sum)
  blk4_c = apply(apply(count_matrix,c(1,4),per_square), 1,sum)
  MLEstat_8m[,4] = blk4/blk4_c
  #blk5 = apply(s_matrix,c(1,2,3),per_square) %>% apply(1,sum)
  blk5 = apply(apply(s_matrix,c(1,2,3),per_square), 1,sum)
  #blk5_c = apply(count_matrix,c(1,2,3),per_square) %>% apply(1,sum)
  blk5_c =  apply(apply(count_matrix,c(1,2,3),per_square),1,sum)
  MLEstat_8m[,5] = blk5/blk5_c
  #blk6 = apply(s_matrix,c(1,3),per_square) %>% apply(1,sum)
  blk6 = apply(apply(s_matrix,c(1,3),per_square),1,sum)
  #blk6_c = apply(count_matrix,c(1,3),per_square) %>% apply(1,sum)
  blk6_c =  apply(apply(count_matrix,c(1,3),per_square),1,sum)
  MLEstat_8m[,6] = blk6/blk6_c
  #blk7 = apply(s_matrix,c(1,2),per_square) %>% apply(1,sum)
  blk7 =  apply(apply(s_matrix,c(1,2),per_square),1,sum)
  #blk7_c = apply(count_matrix,c(1,2),per_square) %>% apply(1,sum)
  blk7_c =  apply(apply(count_matrix,c(1,2),per_square), 1,sum)
  MLEstat_8m[,7] = blk7/blk7_c
  blk8 = apply(s_matrix,1,per_square)
  blk8_c = apply(count_matrix,1,per_square)
  MLEstat_8m[,8] = blk8/blk8_c

  ## moments 1-8 for reader average AUC estimates

  Ustat_coef = matrix(0,nrow = 2,ncol = 8)
  Ustat_8m[,1] = blk1/blk1_c
  Ustat_coef[,1] = 1/blk1_c
  Ustat_8m[,2] = (blk2 - blk1)/(blk2_c - blk1_c)
  Ustat_coef[,2] = 1/(blk2_c - blk1_c)
  Ustat_8m[,3] = (blk3 - blk1)/(blk3_c - blk1_c)
  Ustat_coef[,3] = 1/(blk3_c - blk1_c)
  Ustat_8m[,4] = (blk4 - blk3 - blk2 + blk1)/(blk4_c - blk3_c - blk2_c + blk1_c)
  Ustat_coef[,4] = 1/(blk4_c - blk3_c - blk2_c + blk1_c)
  Ustat_8m[,5] = (blk5 - blk1)/(blk5_c - blk1_c)
  Ustat_coef[,5] = 1/(blk5_c - blk1_c)
  Ustat_8m[,6] = (blk6 - blk5 - blk2 + blk1)/(blk6_c - blk5_c - blk2_c + blk1_c)
  Ustat_coef[,6] = 1/(blk6_c - blk5_c - blk2_c + blk1_c)
  Ustat_8m[,7] = (blk7 - blk5 - blk3 + blk1)/(blk7_c - blk5_c - blk3_c + blk1_c)
  Ustat_coef[,7] = 1/(blk7_c - blk5_c - blk3_c + blk1_c)
  Ustat_8m[,8] = (blk8 - blk4 + blk5 - blk7 + blk3 - blk1 - blk6 + blk2)/(blk8_c 
                  - blk4_c + blk5_c - blk7_c + blk3_c - blk1_c - blk6_c + blk2_c)
  Ustat_coef[,8] = 1/(blk8_c - blk4_c + blk5_c - blk7_c + blk3_c - blk1_c - blk6_c + blk2_c)


  #1/((blk2_c-blk1_c)/blk1_c+1)
  #1/((blk3_c-blk1_c)/blk1_c+1)
  #BCK_coef

  ## reader average AUC estimates
  #AUCA=mean(AUC_out[1,])
  #AUCB=mean(AUC_out[2,])

  AUCA = (apply(s_matrix,c(1),sum)/apply(count_matrix,c(1),sum))[1]
  AUCB = (apply(s_matrix,c(1),sum)/apply(count_matrix,c(1),sum))[2]
  ## combine 8 moments for variance estimates
  #AvgAUC_var=1/nR*(c1*Ustat_8m[,1]+c2*Ustat_8m[,2]+c3*Ustat_8m[,3]+c4*Ustat_8m[,4])+(nR-1)/nR*(c1*Ustat_8m[,5]+c2*Ustat_8m[,6]+
  #c3*Ustat_8m[,7]+c4*Ustat_8m[,8])-Ustat_8m[,8]

  AvgAUC_var = blk8/blk8_c - Ustat_8m[,8]


  BDG_coef = (1/Ustat_coef)/blk1_c^2 - cbind(matrix(0,nrow = 2,ncol = 7),c(1,1))

  trans_m = matrix(c(1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0 ,
                  1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0 ,
                  1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0 ,
                  1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0 ,
                  1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0 ,
                  1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ,
                  1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0), nrow = 7, ncol = 8,byrow = T)

  BCK_coef = BDG_coef %*% t(trans_m)
  #Ustat_coef[,8]= Ustat_coef[,8]-1
  #MLEstat_var=1/nR*(c1*MLEstat_8m[,1]+c2*MLEstat_8m[,2]+c3*MLEstat_8m[,3]+c4*MLEstat_8m[,4])+(nR-1)/nR*(c1*MLEstat_8m[,5]+c2*MLEstat_8m[,6]+
  #                                                                                                        c3*MLEstat_8m[,7]+c4*MLEstat_8m[,8])-MLEstat_8m[,8]
  MLEstat_var = apply(BDG_coef*MLEstat_8m,1,sum)
  out2 = data.frame(modality = modalities,AvgAUC_est = c(AUCA,AUCB),Ustat_var = AvgAUC_var,MLEstat_var = MLEstat_var)

  Ustat_var_BCK = t(B_alpha %*% t(Ustat_8m))
  MLEstat_var_BCK = t(B_alpha %*% t(MLEstat_8m))



  out = list(out1,out2,Ustat_8m,MLEstat_8m,Ustat_var_BCK,MLEstat_var_BCK,BDG_coef,BCK_coef)
  return(out)

}


## function for calculating building block of moments estimate
ps_cov = function(x){

  return(sum(x[1,] %*% t(x[2,])))
}
ps_cov1 = function(x){
  return(sum(as.vector(x[1,,]) %*% t(as.vector(x[2,,]))))
}



AUC_cov_arbitrary = function(s_output){

  B_alpha = matrix(c(0,0,0,0,0,0,1,-1,
                     0,0,0,0,0,1,0,-1,
                     0,0,0,0,1,-1,-1,1,
                     0,0,0,1,0,0,0,-1,
                     0,0,1,-1,0,0,-1,1,
                     0,1,0,-1,0,-1,0,1,
                     1,-1,-1,1,-1,1,1,-1),nrow = 7,ncol = 8,byrow = T)

  s_matrix = s_output[[1]]
  count_matrix = s_output[[2]]
  nm = dim(s_matrix)[1]
  if (nm != 2) {stop("Number of modality is bigger than 2, for now only 2 modilaties are coded")}
  nR = dim(s_matrix)[4]
  nC.neg = dim(s_matrix)[3]
  nC.pos = dim(s_matrix)[2]






  b1 = apply((s_matrix[1,,,])*(s_matrix[2,,,]),3,sum)
  c1 = apply((count_matrix[1,,,])*(count_matrix[2,,,]),3,sum)
  #b2 = apply(s_matrix,c(3,4),ps_cov) %>% apply(2,sum)
  b2 =  apply(apply(s_matrix,c(3,4),ps_cov),2,sum)
  #c2 = apply(count_matrix,c(3,4),ps_cov) %>% apply(2,sum)
  c2 =  apply(apply(count_matrix,c(3,4),ps_cov),2,sum)
  #b3 = apply(s_matrix,c(2,4),ps_cov) %>% apply(2,sum)
  b3 =  apply(apply(s_matrix,c(2,4),ps_cov), 2,sum)
  #c3 = apply(count_matrix,c(2,4),ps_cov) %>% apply(2,sum)
  c3 =  apply(apply(count_matrix,c(2,4),ps_cov),2,sum)
  b4 = apply(s_matrix,4,ps_cov1)
  c4 = apply(count_matrix,4,ps_cov1)


  # M1=b1/(nC.neg*nC.pos)
  # M2=(b2-b1)/(nC.neg*nC.pos*(nC.neg-1))
  # M3=(b3-b1)/(nC.neg*nC.pos*(nC.pos-1))
  # M4=(b4-b2-b3+b1)/(nC.neg*nC.pos*(nC.pos-1)*(nC.neg-1))
  M1 = b1/c1
  M2 = (b2 - b1)/(c2 - c1)
  M3 = (b3 - b1)/(c3 - c1)
  M4 = (b4 - b2 - b3 + b1)/(c4 - c2 - c3 + c1)

  #covAUC_pereader=c1*M1+c2*M2+c3*M3+(c4-1)*M4
  c5 = apply((count_matrix)^2,c(1,4),sum)
  covAUC_pereader = (M1*c1 + M2*(c2 - c1) + M3*(c3 - c1) + M4*(c4 - c2 - c3 + c1))/(c5[1,]*c5[2,]) - M4

  ## buliding block for moments estimate
  blk1 = sum((s_matrix[1,,,])*(s_matrix[2,,,]))
  blk1_c = sum((count_matrix[1,,,])*(count_matrix[2,,,]))
  #blk2 = apply(s_matrix,c(3,4),ps_cov) %>% sum()
  blk2 = sum(apply(s_matrix,c(3,4),ps_cov))
  #blk2_c = apply(count_matrix,c(3,4),ps_cov) %>% sum()
  blk2_c = sum(apply(count_matrix,c(3,4),ps_cov))
  #blk3 = apply(s_matrix,c(2,4),ps_cov) %>% sum()
  blk3 =  sum(apply(s_matrix,c(2,4),ps_cov))
  #blk3_c = apply(count_matrix,c(2,4),ps_cov) %>% sum()
  blk3_c = sum(apply(count_matrix,c(2,4),ps_cov))
  #blk4 = apply(s_matrix,4,ps_cov1) %>% sum()
  blk4 =  sum(apply(s_matrix,4,ps_cov1))
  #blk4_c = apply(count_matrix,4,ps_cov1) %>% sum()
  blk4_c =  sum(apply(count_matrix,4,ps_cov1))
  #blk5 = apply(s_matrix,c(2,3),ps_cov) %>% sum()
  blk5 = sum(apply(s_matrix,c(2,3),ps_cov))
  #blk5_c = apply(count_matrix,c(2,3),ps_cov) %>% sum()
  blk5_c =  sum(apply(count_matrix,c(2,3),ps_cov))
  #blk6 = apply(s_matrix,3,ps_cov1) %>% sum()
  blk6 =  sum(apply(s_matrix,3,ps_cov1))
  #blk6_c = apply(count_matrix,3,ps_cov1) %>% sum()
  blk6_c = sum(apply(count_matrix,3,ps_cov1))
  #blk7 = apply(s_matrix,2,ps_cov1) %>% sum()
  blk7 =  sum(apply(s_matrix,2,ps_cov1))
  #blk7_c = apply(count_matrix,2,ps_cov1) %>% sum()
  blk7_c = sum(apply(count_matrix,2,ps_cov1))
  blk8 = sum(as.vector(s_matrix[1,,,]) %*% t(as.vector(s_matrix[2,,,])))
  blk8_c = sum(as.vector(count_matrix[1,,,]) %*% t(as.vector(count_matrix[2,,,])))


  blk2_mean = blk2/blk2_c

  blk3_mean = blk3/blk3_c

  blk4_mean = blk4/blk4_c

  blk5_mean = blk5/blk5_c

  blk6_mean = blk6/blk6_c

  blk7_mean = blk7/blk7_c

  blk8_mean = blk8/blk8_c

  ## moments 1-8 for reader average AUC estimates

  Ustat_cov_8m = rep(0,8)
  # Ustat_cov_8m[1] = blk1/blk1_c
  # Ustat_cov_8m[2] = (blk2-blk1)/(blk2_c-blk1_c)
  # Ustat_cov_8m[3] = (blk3-blk1)/(blk3_c-blk1_c)
  # Ustat_cov_8m[4] = (blk4-blk3-blk2+blk1)/(blk4_c-blk3_c-blk2_c+blk1_c)
  # Ustat_cov_8m[5] = (blk5-blk1)/(blk5_c-blk1_c)
  # Ustat_cov_8m[6] = (blk6-blk5-blk2+blk1)/(blk6_c-blk5_c-blk2_c+blk1_c)
  # Ustat_cov_8m[7] = (blk7-blk5-blk3+blk1)/(blk7_c-blk5_c-blk3_c+blk1_c)
  # Ustat_cov_8m[8] = (blk8-blk4+blk5-blk7+blk3-blk1-blk6+blk2)/(blk8_c-blk4_c+blk5_c-blk7_c+blk3_c-blk1_c-blk6_c+blk2_c)
  #


  Ustat_coef = rep(0,8)
  Ustat_cov_8m[1] = blk1/blk1_c
  Ustat_coef[1] = 1/blk1_c
  Ustat_cov_8m[2] = (blk2 - blk1)/(blk2_c - blk1_c)
  Ustat_coef[2] = 1/(blk2_c - blk1_c)
  Ustat_cov_8m[3] = (blk3 - blk1)/(blk3_c - blk1_c)
  Ustat_coef[3] = 1/(blk3_c - blk1_c)
  Ustat_cov_8m[4] = (blk4 - blk3 - blk2 + blk1)/(blk4_c - blk3_c - blk2_c + blk1_c)
  Ustat_coef[4] = 1/(blk4_c - blk3_c - blk2_c + blk1_c)
  Ustat_cov_8m[5] = (blk5 - blk1)/(blk5_c - blk1_c)
  Ustat_coef[5] = 1/(blk5_c - blk1_c)
  Ustat_cov_8m[6] = (blk6 - blk5 - blk2 + blk1)/(blk6_c - blk5_c - blk2_c + blk1_c)
  Ustat_coef[6] = 1/(blk6_c - blk5_c - blk2_c + blk1_c)
  Ustat_cov_8m[7] = (blk7 - blk5 - blk3 + blk1)/(blk7_c - blk5_c - blk3_c + blk1_c)
  Ustat_coef[7] = 1/(blk7_c - blk5_c - blk3_c + blk1_c)
  Ustat_cov_8m[8] = (blk8 - blk4 + blk5 - blk7 + blk3 - blk1 - blk6 + blk2)/(blk8_c 
                     - blk4_c + blk5_c - blk7_c + blk3_c - blk1_c - blk6_c + blk2_c)
  Ustat_coef[8] = 1/(blk8_c - blk4_c + blk5_c - blk7_c + blk3_c - blk1_c - blk6_c + blk2_c)


  Nm = apply((count_matrix)^2,c(1),sum)

  BDG_coef = (1/Ustat_coef)/(Nm[1]*Nm[2]) - c(rep(0,7),1)

  trans_m = matrix(c(1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0 ,
                     1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0 ,
                     1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0 ,
                     1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0 ,
                     1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0 ,
                     1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ,
                     1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0), nrow = 7, ncol = 8,byrow = T)

  BCK_coef = BDG_coef %*% t(trans_m)







  ## combine 8 moments for variance estimates
  #Ustat_cov=1/nR*(c1*Ustat_cov_8m[1]+c2*Ustat_cov_8m[2]+c3*Ustat_cov_8m[3]+c4*Ustat_cov_8m[4])+(nR-1)/nR*(c1*Ustat_cov_8m[5]+c2*Ustat_cov_8m[6]+
  #                                                                                                          c3*Ustat_cov_8m[7]+c4*Ustat_cov_8m[8])-Ustat_cov_8m[8]
  Ustat_cov = blk8/blk8_c - Ustat_cov_8m[8]
  #MLEstat_cov=1/nR*(c1*Ustat_cov_8m[1]+c2*blk2_mean+c3*blk3_mean+c4*blk4_mean)+(nR-1)/nR*(c1*blk5_mean+c2*blk6_mean+c3*blk7_mean+c4*blk8_mean)-blk8_mean

  MLEstat_cov_8m = c(Ustat_cov_8m[1],blk2_mean,blk3_mean,blk4_mean,blk5_mean,blk6_mean,blk7_mean,blk8_mean)
  MLEstat_cov = sum(BDG_coef*MLEstat_cov_8m)
  Ustat_cov_BCK = t(B_alpha %*% Ustat_cov_8m)
  MLEstat_cov_BCK = t(B_alpha %*% MLEstat_cov_8m)

  return(list(covAUC_pereader,Ustat_cov,MLEstat_cov,Ustat_cov_8m,MLEstat_cov_8m,Ustat_cov_BCK,MLEstat_cov_BCK,BDG_coef,BCK_coef))

}
