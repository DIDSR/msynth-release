#' MRMC analysis for arbitray design dataset
#'
#'
#'
#' @description This function takes arbitray design MRMC data frame and runs a multi-reader multi-case analysis
#' based on on U-statistics as described in the following papers:
#' Gallas2006_Acad-Radiol_v13p353 (single-modality),
#' Gallas2008_Neural-Networks_v21p387 (multiple modalities, arbitrary study designs),
#' Gallas2009_Commun-Stat-A-Theor_v38p2586 (framework paper).
#'
#'
#'
#'
#'
#' @param data character string or data frame containing the following variables:
#' \itemize{
#'   \item \code{readerID, Factor} with levels like "reader1", "reader2", ...
#'   \item \code{caseID, Factor} with levels like "case1", "case2", ...
#'   \item \code{modalityID, Factor} with levels like "modality1", "modality2", ...
#'   \item \code{score, num} reader score
#' }
#'
#' If data is a character string, it is a file name in the .imrmc format.
#'
#' Each row of this data frame corresponds to an observation.
#' For every caseID, there must be a row corresponding to the truth observation.
#' The readerID for a truth observation is "truth".
#' The modalityID for a truth observation is "truth".
#' The score for a truth observation must be either 0 (signal-absent) or 1 (signal-present).
#'
#' @return The MRMC analysis results, below is a quick summary:
#'
#'
#'
#' \itemize{
#'   \item {\code{perReader, data.frame}
#'    this data frame contains the performance results for each reader.
#'              Key variables of this data frame are AUCA, AUCB, AUCAminusAUCB and the corresponding
#'              variances, confidence intervals, degrees of freedom and p-values.}
#'   \item {\code{Ustat, data.frame}
#'    this data frame contains the reader-average performance results.
#'              The analysis results are based on U-statistics and the papers listed above.
#'              Key variables of this data frame are AUCA, AUCB, AUCAminusAUCB and the corresponding
#'              variances, confidence intervals, degrees of freedom and p-values.}
#'   \item {\code{MLEstat, data.frame}
#'    this data frame contains the reader-average performance results.
#'              The analysis results are based on V-statistics, which approximates the true distribution with
#'              the empirical distribution. The empirical distribution equals the nonparametric MLE
#'              estimate of the true distribution, which is also equivalent to the ideal bootstrap estimate.
#'              Please refer to the papers listed above.
#'              Key variables of this data frame are AUCA, AUCB, AUCAminusAUCB and the corresponding
#'              variances, confidence intervals, degrees of freedom and p-values.
#'   }
#'   \item {\code{ROC, list}
#'    each object of this list is an object containing an ROC curve.
#'              There is an ROC curve for every combination of reader and modality.
#'              For every modality, there are also four average ROC curves. These are discussed in
#'                Chen2014_Br-J-Radiol_v87p20140016.
#'                The diagonal average averages the reader-specific ROC curves along y = -x + b for b in (0,1).
#'                The horizontal average averages the reader specific ROC curves along y = b for b in (0,1).
#'                The vertical average averages the reader specific ROC curves along x = b for b in (0,1).
#'                The pooled average ignores readerID and pools all the scores together to create one ROC curve.
#'   }
#' }
#'
#'
#' @export
#@examples
#'
#'
doIMRMC_R = function(data){
  
  result_AUC_MRMC <- doAUCmrmc(data, flagROC = TRUE)

  # Make a perReader object almost look like version 4.0.3 and earlier
  perReader <- origPerReader(result_AUC_MRMC)
  
  # Make a Ustat object almost look like version 4.0.3 and earlier
  Ustat <- origUstat(result_AUC_MRMC)
  
  # Make an MLEstat object almost look like version 4.0.3 and earlier
  MLEstat <- origMLEstat(result_AUC_MRMC)
  
  # Make a varDecomp object almost look like version 4.0.3 and earlier
  varDecomp <- "varDecomp is only returned when nM = 2"
  if (result_AUC_MRMC$summaryMRMC$nM == 2)
    varDecomp <- origVarDecomp(result_AUC_MRMC)
  
  # Get ROC curves
  ROC <- result_AUC_MRMC$ROC
  
  # Return ####################################################################
  return(list(
    perReader = perReader,
    Ustat = Ustat,
    MLEstat = MLEstat,
    varDecomp = varDecomp,
    ROC = ROC,
    full = result_AUC_MRMC
  ))

}

origPerReader <- function(result_AUC_MRMC) {
  
  current <- result_AUC_MRMC$perReader.full
  nM <- result_AUC_MRMC$summaryMRMC$nM
  
  ####
  #### I would like to change the perReader output
  #### in the revised version of doIMRMC.
  #### 
  #### To do the testing,
  #### we need to shape the data frame to reproduce results iMRMC package
  #### We'll do this from the first column to the last
  #### 
  
  # First, select rows where readerID.1 == readerID.2
  index.TF <- current[, "readerID.1"] == current[, "readerID.2"]
  current <- current[index.TF, ]
  
  # Rename the row names
  rownames(current) <- NULL
  
  # Rename the readerID.1 column to readerID
  current <- iMRMC::renameCol(current, "readerID.1", "readerID")
  
  # Delete the readerID.2 column
  current <- subset(current, select = -readerID.2)
  
  # R doesn't use generally use "integer" types, default is "numeric" type
  # The original code was java and returned "integer" type for N0 and N1
  # Convert the type to achieve agreement
  current$N0 <- as.integer(current$N0)
  current$N1 <- as.integer(current$N1)
  
  # Rename the modalityID columns
  current <- iMRMC::renameCol(current, "modalityID.1", "modalityA")
  current <- iMRMC::renameCol(current, "modalityID.2", "modalityB")
  
  # Rename the AUC.1 and AUC.2 columns to AUCA and AUCB
  current <- iMRMC::renameCol(current, "AUC.1", "AUCA")
  current <- iMRMC::renameCol(current, "AUC.2", "AUCB")
  
  # Create new columns for varAUCA and varAUCB and fill them appropriately
  current$varAUCA <- as.logical(NA)
  current$varAUCB <- as.logical(NA)
  
  # When the modalities are the same, varAUCA = varAUCB = covAUC
  index.TF <- current$modalityA == current$modalityB
  current$varAUCA[index.TF] <- current$covAUC[index.TF]
  current$varAUCB[index.TF] <- current$covAUC[index.TF]
  
  # When the modalities are different, fill them appropriately
  index.TF <- current$modalityA != current$modalityB
  current.12 <- current[index.TF, ]
  if (nM > 1) {
    for (i in 1:sum(index.TF)) {
      current.i <- current[
        (current$readerID == current.12$readerID[i]) &
          (current$modalityA == current.12$modalityA[i]) &
          (current$modalityB == current.12$modalityA[i]), 
      ]
      current.12$varAUCA[i] <- current.i$varAUCA
      current.i <- current[
        (current$readerID == current.12$readerID[i]) &
          (current$modalityA == current.12$modalityB[i]) &
          (current$modalityB == current.12$modalityB[i]), 
      ]
      current.12$varAUCB[i] <- current.i$varAUCB
    }
    current[index.TF, c("varAUCA", "varAUCB")] <- current.12[, c("varAUCA", "varAUCB")]
  }
  
  # Add columns for AUCAminusAUCB and varAUCAminusAUCB
  current$AUCAminusAUCB <- current$AUCA - current$AUCB
  current$varAUCAminusAUCB <- current$varAUCA + current$varAUCB - 2 * current$covAUC
  
  # Keep and reorder only what we need
  current <- current[, c(
    "readerID",
    "N0", "N1",
    "modalityA", "modalityB",
    "AUCA", "varAUCA",
    "AUCB", "varAUCB",
    "AUCAminusAUCB", "varAUCAminusAUCB"
  )]
  
  # Special edits to perfectly match original output
  index.TF <- current$modalityA == current$modalityB
  current$modalityB <- as.character(current$modalityB)
  current$modalityB[index.TF] <- "NO_MOD"
  current$modalityB <- factor(current$modalityB)
  current[index.TF, c("AUCB", "varAUCB", "AUCAminusAUCB", "varAUCAminusAUCB")] <- NA
  
  return(current)
  
}

origUstat <- function(result_AUC_MRMC) {
  
  current <- result_AUC_MRMC$Ustat.full
  nM <- result_AUC_MRMC$summaryMRMC$nM

  # Rename the modalityID columns
  current <- iMRMC::renameCol(current, "modalityID.1", "modalityA")
  current <- iMRMC::renameCol(current, "modalityID.2", "modalityB")
  
  # Create a Ustat column  
  current$UstatOrMLE <- factor("Ustat")
  
  # Rename the AUC.1 and AUC.2 columns to AUCA and AUCB
  current <- iMRMC::renameCol(current, "AUC.1", "AUCA")
  current <- iMRMC::renameCol(current, "AUC.2", "AUCB")
  
  # Create new columns for varAUCA and varAUCB and fill them appropriately
  current$varAUCA <- NA
  current$varAUCB <- NA
  
  # When the modalities are the same, varAUCA = varAUCB = covAUC
  index.TF <- current$modalityA == current$modalityB
  current$varAUCA[index.TF] <- current$covAUC[index.TF]
  current$varAUCB[index.TF] <- current$covAUC[index.TF]
  
  ####
  #### When the modalities are different, fill them appropriately
  #### 
  
  # Select the rows of corresponding to different modalities
  index.TF <- current$modalityA != current$modalityB
  current.12 <- current[index.TF, ]
  
  # For each row that has different modalities,
  # Fill in varAUCA, varAUCB, and dfBDG
  if (nM > 1) {
    
    for (i in 1:sum(index.TF)) {
      current.i <- current[
        (current$modalityA == current.12$modalityA[i]) &
          (current$modalityB == current.12$modalityA[i]), ]
      current.12$varAUCA[i] <- current.i$varAUCA
      
      current.i <- current[
        (current$modalityA == current.12$modalityB[i]) &
          (current$modalityB == current.12$modalityB[i]), ]
      current.12$varAUCB[i] <- current.i$varAUCB
      
      current.12$dfBDG <- current.12$dfBDG.diff
    }
    current[index.TF, c("varAUCA", "varAUCB", "dfBDG")] <- 
      current.12[, c("varAUCA", "varAUCB", "dfBDG")]
    
  }
  
  # Add columns for AUCAminusAUCB and varAUCAminusAUCB
  current <- iMRMC::renameCol(current, "AUC1minusAUC2", "AUCAminusAUCB")
  current <- iMRMC::renameCol(current, "varAUC1minusAUC2", "varAUCAminusAUCB")
  
  # Keep and reorder only what we need
  current <- current[, c(
    "NR", "N0", "N1",
    "modalityA", "modalityB",
    "UstatOrMLE",
    "AUCA", "varAUCA",
    "AUCB", "varAUCB",
    "AUCAminusAUCB", "varAUCAminusAUCB",
    "pValueNormal",
    "botCInormal", "topCInormal",
    "rejectNormal",
    "dfBDG",
    "pValueBDG",
    "botCIBDG", "topCIBDG",
    "rejectBDG"
  )]

  # Special edits to perfectly match original output
  index.TF <- current$modalityA == current$modalityB
  current$modalityB <- as.character(current$modalityB)
  current$modalityB[index.TF] <- "NO_MOD"
  current$modalityB <- factor(current$modalityB)
  current[index.TF, c("AUCB", "varAUCB", "AUCAminusAUCB", "varAUCAminusAUCB")] <- NA
  current <- iMRMC::renameCol(current, "dfBDG.diff", "dfBDG")
  current <- iMRMC::renameCol(current, "pValueBDG.diff", "pValueBDG")
  current <- iMRMC::renameCol(current, "botCIBDG.diff", "botCIBDG")
  current <- iMRMC::renameCol(current, "topCIBDG.diff", "topCIBDG")
  current <- iMRMC::renameCol(current, "rejectBDG.diff", "rejectBDG")
  
  return(current)
  
}

origMLEstat <- function(result_AUC_MRMC) {
  
  current <- result_AUC_MRMC$Ustat.full
  nM <- result_AUC_MRMC$summaryMRMC$nM
  
  # Rename the modalityID columns
  current <- iMRMC::renameCol(current, "modalityID.1", "modalityA")
  current <- iMRMC::renameCol(current, "modalityID.2", "modalityB")
  
  # Create a Ustat column  
  current$UstatOrMLE <- factor("MLE")
  
  # Rename the AUC.1 and AUC.2 columns to AUCA and AUCB
  current <- iMRMC::renameCol(current, "AUC.1", "AUCA")
  current <- iMRMC::renameCol(current, "AUC.2", "AUCB")
  
  # Create new columns for varAUCA and varAUCB and fill them appropriately
  current$varAUCA <- NA
  current$varAUCB <- NA
  
  # When the modalities are the same, varAUCA = varAUCB = covAUC
  index.TF <- current$modalityA == current$modalityB
  current$varAUCA[index.TF] <- current$covAUC.biased[index.TF]
  current$varAUCB[index.TF] <- current$covAUC.biased[index.TF]

  # Set dfBDG to be the biased versions
  current$dfBDG <- current$dfBDG.biased
  
  ####
  #### When the modalities are different, fill them appropriately
  #### 
  
  # Select the rows of corresponding to different modalities
  index.TF <- current$modalityA != current$modalityB
  current.12 <- current[index.TF, ]
  
  # For each row that has different modalities,
  # Fill in varAUCA, varAUCB 
  if (nM > 1) {
    
    for (i in 1:sum(index.TF)) {
      current.i <- current[
        (current$modalityA == current.12$modalityA[i]) &
          (current$modalityB == current.12$modalityA[i]), ]
      current.12$varAUCA[i] <- current.i$covAUC.biased
      
      current.i <- current[
        (current$modalityA == current.12$modalityB[i]) &
          (current$modalityB == current.12$modalityB[i]), ]
      current.12$varAUCB[i] <- current.i$covAUC.biased
    }
    current[index.TF, c("varAUCA", "varAUCB", "dfBDG")] <- 
      current.12[, c("varAUCA", "varAUCB", "dfBDG.biased.diff")]
    
  }
  
  # Add columns for AUCAminusAUCB and varAUCAminusAUCB
  current <- iMRMC::renameCol(current, "AUC1minusAUC2", "AUCAminusAUCB")
  current <- iMRMC::renameCol(current, "varAUC1minusAUC2.biased", "varAUCAminusAUCB")
  
  # Replace unbiased hypothesis test results with biased results
  current$pValueNormal <- current$pValueNormal.biased
  current$botCInormal <- current$botCInormal.biased
  current$topCInormal <- current$topCInormal.biased
  current$rejectNormal <- current$rejectNormal.biased
  current$pValueBDG <- current$pValueBDG.biased
  current$botCIBDG <- current$botCIBDG.biased
  current$topCIBDG <- current$topCIBDG.biased
  current$rejectBDG <- current$rejectBDG.biased
  
  # Keep and reorder only what we need
  current <- current[, c(
    "NR", "N0", "N1",
    "modalityA", "modalityB",
    "UstatOrMLE",
    "AUCA", "varAUCA",
    "AUCB", "varAUCB",
    "AUCAminusAUCB", "varAUCAminusAUCB",
    "pValueNormal",
    "botCInormal", "topCInormal",
    "rejectNormal",
    "dfBDG",
    "pValueBDG",
    "botCIBDG", "topCIBDG",
    "rejectBDG"
  )]
  
  # Special edits to perfectly match original output
  index.TF <- current$modalityA == current$modalityB
  current$modalityB <- as.character(current$modalityB)
  current$modalityB[index.TF] <- "NO_MOD"
  current$modalityB <- factor(current$modalityB)
  current[index.TF, c("AUCB", "varAUCB", "AUCAminusAUCB", "varAUCAminusAUCB")] <- NA
  
  return(current)
  
}

origVarDecomp <- function(result_AUC_MRMC) {
  
  Ustat.full <- result_AUC_MRMC$Ustat.full
  summaryMRMC <- result_AUC_MRMC$summaryMRMC
  nM <- result_AUC_MRMC$summaryMRMC$nM
  
  # Make the varDecomp object look like version 4.0.3 and earlier
  varDecomp.BDG.Ustat <- origVarDecomp.BDG.Ustat(Ustat.full, summaryMRMC)
  
  # Make the varDecomp object look like version 4.0.3 and earlier
  varDecomp.BDG.MLE <- origVarDecomp.BDG.MLE(Ustat.full, summaryMRMC)
  
  # Make the varDecomp object look like version 4.0.3 and earlier
  varDecomp.BCK.Ustat <- origVarDecomp.BCK.Ustat(Ustat.full, summaryMRMC)
  
  # Make the varDecomp object look like version 4.0.3 and earlier
  varDecomp.BCK.MLE <- origVarDecomp.BCK.MLE(Ustat.full, summaryMRMC)
  
  varDecomp.BCK <- list(
    MLE = varDecomp.BCK.MLE,
    Ustat = varDecomp.BCK.Ustat)
  
  varDecomp.BDG <- list(
    MLE = varDecomp.BDG.MLE,
    Ustat = varDecomp.BDG.Ustat)
  
  varDecomp <- list(BCK = varDecomp.BCK, BDG = varDecomp.BDG)
  
  return(varDecomp)
  
}

origVarDecomp.BDG.Ustat <- function(Ustat.full, summaryMRMC) {

  nM <- summaryMRMC$nM
  modalities <- summaryMRMC$modalities
  
  desc.comp.BDG <- c(
    "modalityID.1", "modalityID.2",
    "M1", "M2", "M3", "M4",
    "M5", "M6", "M7", "M8")
  
  comp <- Ustat.full[, desc.comp.BDG]
  comp$modalityID.1 <- factor(comp$modalityID.1)
  comp$modalityID.2 <- factor(comp$modalityID.2)
  
  desc.coeff.BDG <- c(
    "modalityID.1", "modalityID.2",
    "M1.coeff", "M2.coeff", "M3.coeff", "M4.coeff",
    "M5.coeff", "M6.coeff", "M7.coeff", "M8.coeff")

  coeff <- Ustat.full[, desc.coeff.BDG]
  names(coeff) <- c(
    "modalityID.1", "modalityID.2",
    "M1", "M2", "M3", "M4",
    "M5", "M6", "M7", "M8")
  
  coeff$modalityID.1 <- factor(coeff$modalityID.1)
  coeff$modalityID.2 <- factor(coeff$modalityID.2)
  
  ####
  #### Single modalities loop
  #### 
  comp.full <- list()
  coeff.full <- list()
  for (modality.1 in 1:nM) {
    
    desc <- c(
      modalities[modality.1],
      "NO_MOD",
      paste(modalities[modality.1], "NO_MOD", sep = ".")
    )
    
    comp.temp <- comp[, 3:10] * 0
    comp.temp[1, ] <- comp[modality.1, 3:10]
    rownames(comp.temp) <- desc
    
    comp.temp <- list(comp.temp)
    names(comp.temp) <- desc[3]
    comp.full <- c(comp.full, comp.temp)
    
    coeff.temp <- coeff[, 3:10] * 0
    coeff.temp[1, ] <- coeff[modality.1, 3:10]
    rownames(coeff.temp) <- desc
    
    coeff.temp <- list(coeff.temp)
    names(coeff.temp) <- desc[3]
    coeff.full <- c(coeff.full, coeff.temp)
    
  }
  
for (modality.1 in 1:(nM - 1)) {
    for (modality.2 in (modality.1 + 1):nM) {
      
      desc <- c(
        modalities[modality.1],
        modalities[modality.2],
        paste(modalities[modality.1], modalities[modality.2], sep = ".")
      )
      
      comp.temp <- comp[, 3:10] * 0
      comp.temp[1, ] <- comp[modality.1, 3:10]
      comp.temp[2, ] <- comp[modality.2, 3:10]
      comp.temp[3, ] <- comp[
        (as.numeric(comp$modalityID.1) == modality.1) &
          (as.numeric(comp$modalityID.2) == modality.2), 3:10]
      rownames(comp.temp) <- desc
      
      comp.temp <- list(comp.temp)
      names(comp.temp) <- desc[3]
      comp.full <- c(comp.full, comp.temp)
      
      coeff.temp <- coeff[, 3:10] * 0
      coeff.temp[1, ] <- coeff[modality.1, 3:10]
      coeff.temp[2, ] <- coeff[modality.2, 3:10]
      coeff.temp[3, ] <- 2 * coeff[
        (as.numeric(coeff$modalityID.1) == modality.1) &
          (as.numeric(comp$modalityID.2) == modality.2), 3:10]
      rownames(coeff.temp) <- desc
      
      coeff.temp <- list(coeff.temp)
      names(coeff.temp) <- desc[3]
      coeff.full <- c(coeff.full, coeff.temp)
      
    }
  } 
  
  result <- list(comp = comp.full, coeff = coeff.full)
  
  return(result)
  
  
}

origVarDecomp.BDG.MLE <- function(Ustat.full, summaryMRMC) {
  
  nM <- summaryMRMC$nM
  modalities <- summaryMRMC$modalities
  
  comp.1 <- data.frame(
    modalityID.1 = Ustat.full$modalityID.1,
    modalityID.2 = Ustat.full$modalityID.2
  )
  
  desc.numer.BDG <- c(
    "numer1", "numer2", "numer3", "numer4",
    "numer5", "numer6", "numer7", "numer8")
  
  desc.denom.BDG <- c(
    "denom1", "denom2", "denom3", "denom4",
    "denom5", "denom6", "denom7", "denom8")
  
  numer <- Ustat.full[, desc.numer.BDG]
  denom <- Ustat.full[, desc.denom.BDG]
  
  comp.2 <- numer / denom
  
  comp <- cbind(comp.1, comp.2)
  
  names(comp) <- c(
    "modalityID.1", "modalityID.2",
    "M1", "M2", "M3", "M4",
    "M5", "M6", "M7", "M8")
  
  
  
  desc.coeff.BDG <- c(
    "modalityID.1", "modalityID.2",
    "M1.coeff", "M2.coeff", "M3.coeff", "M4.coeff",
    "M5.coeff", "M6.coeff", "M7.coeff", "M8.coeff")
  
  coeff <- Ustat.full[, desc.coeff.BDG]
  names(coeff) <- c(
    "modalityID.1", "modalityID.2",
    "M1", "M2", "M3", "M4",
    "M5", "M6", "M7", "M8")
  
  coeff$modalityID.1 <- factor(coeff$modalityID.1)
  coeff$modalityID.2 <- factor(coeff$modalityID.2)
  
  #### 
  #### Paired modalities loops
  #### 
  comp.full <- list()
  coeff.full <- list()
  for (modality.1 in 1:nM) {
    
    desc <- c(
      modalities[modality.1],
      "NO_MOD",
      paste(modalities[modality.1], "NO_MOD", sep = ".")
    )
    
    comp.temp <- comp[, 3:10] * 0
    comp.temp[1, ] <- comp[modality.1, 3:10]
    rownames(comp.temp) <- desc
    
    comp.temp <- list(comp.temp)
    names(comp.temp) <- desc[3]
    comp.full <- c(comp.full, comp.temp)
    
    coeff.temp <- coeff[, 3:10] * 0
    coeff.temp[1, ] <- coeff[modality.1, 3:10]
    rownames(coeff.temp) <- desc
    
    coeff.temp <- list(coeff.temp)
    names(coeff.temp) <- desc[3]
    coeff.full <- c(coeff.full, coeff.temp)
    
  }
  
  for (modality.1 in 1:(nM - 1)) {
    for (modality.2 in (modality.1 + 1):nM) {
      
      desc <- c(
        modalities[modality.1],
        modalities[modality.2],
        paste(modalities[modality.1], modalities[modality.2], sep = ".")
      )
      
      comp.temp <- comp[, 3:10] * 0
      comp.temp[1, ] <- comp[modality.1, 3:10]
      comp.temp[2, ] <- comp[modality.2, 3:10]
      comp.temp[3, ] <- comp[
        (as.numeric(comp$modalityID.1) == modality.1) &
          (as.numeric(comp$modalityID.2) == modality.2), 3:10]
      rownames(comp.temp) <- desc
      
      comp.temp <- list(comp.temp)
      names(comp.temp) <- desc[3]
      comp.full <- c(comp.full, comp.temp)
      
      coeff.temp <- coeff[, 3:10] * 0
      coeff.temp[1, ] <- coeff[modality.1, 3:10]
      coeff.temp[2, ] <- coeff[modality.2, 3:10]
      coeff.temp[3, ] <- 2 * coeff[
        (as.numeric(coeff$modalityID.1) == modality.1) &
          (as.numeric(comp$modalityID.2) == modality.2), 3:10]
      rownames(coeff.temp) <- desc
      
      coeff.temp <- list(coeff.temp)
      names(coeff.temp) <- desc[3]
      coeff.full <- c(coeff.full, coeff.temp)
      
    }
  } 
  
  result <- list(comp = comp.full, coeff = coeff.full)
  
  return(result)
  
  
}

origVarDecomp.BCK.Ustat <- function(Ustat.full, summaryMRMC) {
  
  nM <- summaryMRMC$nM
  modalities <- summaryMRMC$modalities
  
  desc.comp.BCK <- c(
    "modalityID.1", "modalityID.2",
    "BCK.N", "BCK.D", "BCK.ND", "BCK.R", "BCK.NR", "BCK.DR", "BCK.RND")

  comp_BCK <- Ustat.full[, desc.comp.BCK]
  names(comp_BCK) <- c("modalityID.1", "modalityID.2",
                        "N", "D", "ND",
                        "R", "NR", "DR", "RND")
  
  desc.coeff.BCK <- c(
    "modalityID.1", "modalityID.2",
    "BCK.N.coeff", "BCK.D.coeff", "BCK.ND.coeff",
    "BCK.R.coeff", "BCK.NR.coeff", "BCK.DR.coeff", "BCK.RND.coeff")
  
  coeff_BCK <- Ustat.full[, desc.coeff.BCK]
  names(coeff_BCK) <- c("modalityID.1", "modalityID.2",
                        "N", "D", "ND",
                        "R", "NR", "DR", "RND")
  
  ####
  #### Paired modalities loops
  #### 
  comp_BCK.full <- list()
  coeff_BCK.full <- list()
  for (modality.1 in 1:nM) {
    
    desc <- c(
      modalities[modality.1],
      "NO_MOD",
      paste(modalities[modality.1], "NO_MOD", sep = ".")
    )
    
    comp_BCK.temp <- comp_BCK[, 3:ncol(comp_BCK)] * 0
    comp_BCK.temp[1, ] <- comp_BCK[modality.1, 3:ncol(comp_BCK)]
    rownames(comp_BCK.temp) <- desc
    
    comp_BCK.temp <- list(comp_BCK.temp)
    names(comp_BCK.temp) <- desc[3]
    comp_BCK.full <- c(comp_BCK.full, comp_BCK.temp)
    
    coeff_BCK.temp <- coeff_BCK[, 3:ncol(coeff_BCK)] * 0
    coeff_BCK.temp[1, ] <- coeff_BCK[modality.1, 3:ncol(coeff_BCK)]
    rownames(coeff_BCK.temp) <- desc
    
    coeff_BCK.temp <- list(coeff_BCK.temp)
    names(coeff_BCK.temp) <- desc[3]
    coeff_BCK.full <- c(coeff_BCK.full, coeff_BCK.temp)
    
  }
  
  for (modality.1 in 1:(nM - 1)) {
    for (modality.2 in (modality.1 + 1):nM) {
      
      desc <- c(
        modalities[modality.1],
        modalities[modality.2],
        paste(modalities[modality.1], modalities[modality.2], sep = ".")
      )
      
      comp_BCK.temp <- comp_BCK[, 3:ncol(comp_BCK)] * 0
      comp_BCK.temp[1, ] <- comp_BCK[modality.1, 3:ncol(comp_BCK)]
      comp_BCK.temp[2, ] <- comp_BCK[modality.2, 3:ncol(comp_BCK)]
      comp_BCK.temp[3, ] <- comp_BCK[
        (as.numeric(comp_BCK$modalityID.1) == modality.1) &
          (as.numeric(comp_BCK$modalityID.2) == modality.2), 3:ncol(comp_BCK)]
      rownames(comp_BCK.temp) <- desc
      
      comp_BCK.temp <- list(comp_BCK.temp)
      names(comp_BCK.temp) <- desc[3]
      comp_BCK.full <- c(comp_BCK.full, comp_BCK.temp)
      
      coeff_BCK.temp <- coeff_BCK[, 3:ncol(coeff_BCK)] * 0
      coeff_BCK.temp[1, ] <- coeff_BCK[modality.1, 3:ncol(coeff_BCK)]
      coeff_BCK.temp[2, ] <- coeff_BCK[modality.2, 3:ncol(coeff_BCK)]
      coeff_BCK.temp[3, ] <- 2 * coeff_BCK[
        (as.numeric(coeff_BCK$modalityID.1) == modality.1) &
          (as.numeric(comp_BCK$modalityID.2) == modality.2), 3:ncol(coeff_BCK)]
      rownames(coeff_BCK.temp) <- desc
      
      coeff_BCK.temp <- list(coeff_BCK.temp)
      names(coeff_BCK.temp) <- desc[3]
      coeff_BCK.full <- c(coeff_BCK.full, coeff_BCK.temp)
      
    }
  } 
  
  result <- list(comp = comp_BCK.full, coeff = coeff_BCK.full)
  
  return(result)
  
  
}

origVarDecomp.BCK.MLE <- function(Ustat.full, summaryMRMC) {
  
  nM <- summaryMRMC$nM
  modalities <- summaryMRMC$modalities
  
  desc.comp.BCK <- c(
    "modalityID.1", "modalityID.2",
    "BCK.N.b", "BCK.D.b", "BCK.ND.b", "BCK.R.b", "BCK.NR.b", "BCK.DR.b", "BCK.RND.b")
  
  comp_BCK <- Ustat.full[, desc.comp.BCK]
  names(comp_BCK) <- c("modalityID.1", "modalityID.2",
                       "N", "D", "ND",
                       "R", "NR", "DR", "RND")
  
  desc.coeff.BCK <- c(
    "modalityID.1", "modalityID.2",
    "BCK.N.coeff", "BCK.D.coeff", "BCK.ND.coeff",
    "BCK.R.coeff", "BCK.NR.coeff", "BCK.DR.coeff", "BCK.RND.coeff")
  
  coeff_BCK <- Ustat.full[, desc.coeff.BCK]
  names(coeff_BCK) <- c("modalityID.1", "modalityID.2",
                        "N", "D", "ND",
                        "R", "NR", "DR", "RND")
  
  ####
  #### Paired modalities loops
  #### 
  comp_BCK.full <- list()
  coeff_BCK.full <- list()
  for (modality.1 in 1:nM) {
    
    desc <- c(
      modalities[modality.1],
      "NO_MOD",
      paste(modalities[modality.1], "NO_MOD", sep = ".")
    )
    
    comp_BCK.temp <- comp_BCK[, 3:ncol(comp_BCK)] * 0
    comp_BCK.temp[1, ] <- comp_BCK[modality.1, 3:ncol(comp_BCK)]
    rownames(comp_BCK.temp) <- desc
    
    comp_BCK.temp <- list(comp_BCK.temp)
    names(comp_BCK.temp) <- desc[3]
    comp_BCK.full <- c(comp_BCK.full, comp_BCK.temp)
    
    coeff_BCK.temp <- coeff_BCK[, 3:ncol(coeff_BCK)] * 0
    coeff_BCK.temp[1, ] <- coeff_BCK[modality.1, 3:ncol(coeff_BCK)]
    rownames(coeff_BCK.temp) <- desc
    
    coeff_BCK.temp <- list(coeff_BCK.temp)
    names(coeff_BCK.temp) <- desc[3]
    coeff_BCK.full <- c(coeff_BCK.full, coeff_BCK.temp)
    
  }
  
  for (modality.1 in 1:(nM - 1)) {
    for (modality.2 in (modality.1 + 1):nM) {
      
      desc <- c(
        modalities[modality.1],
        modalities[modality.2],
        paste(modalities[modality.1], modalities[modality.2], sep = ".")
      )
      
      comp_BCK.temp <- comp_BCK[, 3:ncol(comp_BCK)] * 0
      comp_BCK.temp[1, ] <- comp_BCK[modality.1, 3:ncol(comp_BCK)]
      comp_BCK.temp[2, ] <- comp_BCK[modality.2, 3:ncol(comp_BCK)]
      comp_BCK.temp[3, ] <- comp_BCK[
        (as.numeric(comp_BCK$modalityID.1) == modality.1) &
          (as.numeric(comp_BCK$modalityID.2) == modality.2), 3:ncol(comp_BCK)]
      rownames(comp_BCK.temp) <- desc
      
      comp_BCK.temp <- list(comp_BCK.temp)
      names(comp_BCK.temp) <- desc[3]
      comp_BCK.full <- c(comp_BCK.full, comp_BCK.temp)
      
      coeff_BCK.temp <- coeff_BCK[, 3:ncol(coeff_BCK)] * 0
      coeff_BCK.temp[1, ] <- coeff_BCK[modality.1, 3:ncol(coeff_BCK)]
      coeff_BCK.temp[2, ] <- coeff_BCK[modality.2, 3:ncol(coeff_BCK)]
      coeff_BCK.temp[3, ] <- 2 * coeff_BCK[
        (as.numeric(coeff_BCK$modalityID.1) == modality.1) &
          (as.numeric(comp_BCK$modalityID.2) == modality.2), 3:ncol(coeff_BCK)]
      rownames(coeff_BCK.temp) <- desc
      
      coeff_BCK.temp <- list(coeff_BCK.temp)
      names(coeff_BCK.temp) <- desc[3]
      coeff_BCK.full <- c(coeff_BCK.full, coeff_BCK.temp)
      
    }
  } 
  
  result <- list(comp = comp_BCK.full, coeff = coeff_BCK.full)
  
  return(result)
  
  
}

# SCRIPT ##################################

develop_flag <- FALSE
options(warn = 0)

if (develop_flag) {
  
  # warn = 0, don't stop, don't report
  # warn = 1, don't stop, report
  # warn = 2, stop and report
  options(warn = 2)
  
  library(iMRMC)
  library(testthat)
  
  testthat::context("doIMRMC_R")
  
  # initialize the random number generator
  iMRMC::init.lecuyerRNG()
  
  # Create a sample configuration file
  config <- iMRMC::sim.gRoeMetz.config()
  
  # Simulate an MRMC ROC data set
  dFrame.imrmc <- iMRMC::sim.gRoeMetz(config)
  dFrame.imrmc$modalityID <- as.character(dFrame.imrmc$modalityID)
  dFrame.imrmc$readerID <- as.character(dFrame.imrmc$readerID)
  dFrame.imrmc$caseID <- as.character(dFrame.imrmc$caseID)
  
  ## Delete some data to create "arbitrary" study design
  index.delete = sample(100:880,100)
  dFrame.imrmc <- dFrame.imrmc[-index.delete, ]
  
  # Delete the first reader from modality A and the first case from modality B
  dFrame.imrmc <- dFrame.imrmc[!(
    dFrame.imrmc$modalityID == "testA" &
      dFrame.imrmc$readerID == "reader1"), ]
  dFrame.imrmc <- dFrame.imrmc[!(
    dFrame.imrmc$modalityID == "testB" &
      dFrame.imrmc$caseID == "negCase1"), ]
  
  
  # Rename some negative cases and resort
  # This puts the truth and reader data of the renamed cases
  # at the bottom of the data frame
  for (i in 1:nrow(dFrame.imrmc)) {
    dFrame.imrmc[i, "caseID"] <-
      sub("negCase1", "x-negCase1", dFrame.imrmc[i, "caseID"])
  }
  index <- order(dFrame.imrmc[, "caseID"])
  dFrame.imrmc <- dFrame.imrmc[index, ]
  
  
  # Analyze the MRMC ROC data with java code
  # Processing time
  # user  system elapsed 
  # 0.07    0.04    3.17
  
  if (!exists("result_doIMRMC_expected")) {
    
    start.time <- proc.time()
    system.time({
      result_doIMRMC_expected <- iMRMC::doIMRMC(dFrame.imrmc)
    })
    end.time <- proc.time()
    print(end.time - start.time)
    
  }
  
  
  
  # Analyze the MRMC ROC data using new R code
  # Processing time before BDG
  # user  system elapsed 
  # 3.36    0.81    4.17
  
  start.time <- proc.time()
  system.time({
    result_doIMRMC_current <- doIMRMC_R(dFrame.imrmc)
  })
  end.time <- proc.time()
  print(end.time - start.time)
  
  
  
  # ROC ###############
  expected <- result_doIMRMC_expected$ROC
  current <- result_doIMRMC_current$ROC
  
  browser()
  plot(current$testA.reader2$fpf,
       current$testA.reader2$tpf, type = "l")
  lines(expected$`testA: reader2`$fpf,
        expected$`testA: reader2`$tpf, lty = 2)

  plot(current$testA.pooled$fpf,
       current$testA.pooled$tpf, type = "l")
  lines(expected$`testA: Pooled Average`$fpf,
        expected$`testA: Pooled Average`$tpf, lty = 2)
  
  plot(current$testA.diagonalAvg$fpf,
       current$testA.diagonalAvg$tpf, type = "l")
  lines(expected$`testA: Diagonal Average`$fpf,
        expected$`testA: Diagonal Average`$tpf, lty = 2)
  
  plot(current$testA.verticalAvg$fpf,
       current$testA.verticalAvg$tpf, type = "l")
  lines(expected$`testA: Vertical Average`$fpf,
        expected$`testA: Vertical Average`$tpf, lty = 2)
  
  plot(current$testA.horizontalAvg$fpf,
       current$testA.horizontalAvg$tpf, type = "l")
  lines(expected$`testA: Horizontal Average`$fpf,
        expected$`testA: Horizontal Average`$tpf, lty = 2)
  
  
  
  
  
  
  
  
}
